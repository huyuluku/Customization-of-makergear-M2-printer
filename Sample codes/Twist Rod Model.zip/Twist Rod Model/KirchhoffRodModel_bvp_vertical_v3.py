import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from scipy.integrate import solve_bvp
from scipy import integrate
from scipy import signal
import scipy.ndimage.filters as filters
import scipy.ndimage.morphology as morphology
import os
import shutil   #High level file operation
import time
import sys
import copy
# Figure parameters =================================================
# When you insert the figure, you need to make fig height 2
plt.rcParams['font.family']     = 'sans-serif'
plt.rcParams['figure.figsize']  = 8, 6      # (w=3,h=2) multiply by 3
plt.rcParams['font.size']       = 24        # Original fornt size is 8, multipy by above number
#plt.rcParams['text.usetex']     = True
#plt.rcParams['ps.useafm'] = True
#plt.rcParams['pdf.use14corefonts'] = True
#plt.rcParams['text.latex.preamble'] = '\usepackage{sfmath}'
plt.rcParams['lines.linewidth'] = 3.   
plt.rcParams['lines.markersize'] = 8. 
plt.rcParams['legend.fontsize'] = 20        # Original fornt size is 8, multipy by above number
plt.rcParams['xtick.labelsize'] = 24        # Original fornt size is 8, multipy by above number
plt.rcParams['ytick.labelsize'] = 24        # Original fornt size is 8, multipy by above number
plt.rcParams['xtick.direction'] = 'in'
plt.rcParams['ytick.direction'] = 'in' 
plt.rcParams['figure.subplot.left']  = 0.2
#plt.rcParams['figure.subplot.right']  = 0.7
plt.rcParams['figure.subplot.bottom']  = 0.2
plt.rcParams['savefig.dpi']  = 300


#==============================================================================
# Model the beam of twist kirigami structure as a Kirchhoff rod
#==============================================================================
class Static_KirchhoffRod_perpendicular:
    def __init__(self, thick, width, L_beam, R_hub, Nsec_hub,
                 k1_0, k2_0, tau_0,
                 Eyng, nu_Poi, fname, dir_cwd, N_s, delete_data=True):
        self.thick  = thick
        self.width  = width
        self.L_beam = L_beam
        self.R_hub  = R_hub
        self.Nsec_hub = Nsec_hub
        self.k1_0   = k1_0
        self.k2_0   = k2_0
        self.tau_0  = tau_0
        self.Eyng   = Eyng
        self.nu_Poi = nu_Poi
        self.N_s    = N_s
        self.aspect = width/thick
        self.Rigidities()
        # Directory where the calculation results are saved
        self.fname      = fname
        self.dir_cwd    = dir_cwd
        self.dir_save   = 'TwistKirigami_VTK_Animation'
        # Parameters for the BVP solver
        self.max_nodes  = 10000
        # Delete previous data
        if delete_data==True:
            if os.path.exists(self.dir_cwd+'/'+self.dir_save):
                shutil.rmtree(self.dir_cwd+'/'+self.dir_save)
            os.makedirs(self.dir_cwd+'/'+self.dir_save)
            os.makedirs(self.dir_cwd+'/'+self.dir_save+'/Data_files')
    def Rigidities(self):
#        l_shape = 1./3.
        n_fourier = np.arange(1,10,2)
        self.l_shape = 0.333*(1-np.sum(192/5/np.pi**5/self.aspect*np.tanh(n_fourier*np.pi/2*self.aspect)))
        self.EI1 = (self.Eyng*self.width*self.thick**3)/12.
        self.EI2 = (self.Eyng*self.thick*self.width**3)/12.
        self.GJ  = self.l_shape*(self.Eyng/(2.*(1.+self.nu_Poi))*self.width*self.thick**3)
        # Rigidity ratios
        self.ratio_a = (1.+self.nu_Poi)/(6.*self.l_shape)
        self.ratio_b = (1.+self.nu_Poi)*(self.width/self.thick)**2/(6.*self.l_shape)
        return()
    
    def Equations_Kirchhoff(self, x, y):
        N1 = y[0,:]
        N2 = y[1,:]
        N3 = y[2,:]
        k1 = y[3,:]
        k2 = y[4,:]
#        M2 = y[4,:]
        tau = y[5,:]
        q0  = y[6,:]
        q1  = y[7,:]
        q2  = y[8,:]
        q3  = y[9,:]
        # Force
        dN1 =  N2*tau - N3*k2
        dN2 = -N1*tau + N3*k1
        dN3 = -N2*k1  + N1*k2
#        dN1 = N2*tau
#        dN2 = -N1*tau + N3*k1
#        dN3 = -N2*k1
        # Curvature
        k1_rev  = k1  - self.k1_0
        k2_rev  = k2  - self.k2_0
        tau_rev = tau - self.tau_0
#        dk1 = (M2*tau + N2)/self.ratio_a
#        dk1 = ((self.ratio_b-1.)*k2*tau + N2)/self.ratio_a
#        dk2 = ((1.-self.ratio_a)*k1*tau - N1)/self.ratio_b
#        dtau = (self.ratio_a-self.ratio_b)*k1*k2
        dk1 = ( self.ratio_b*k2_rev*tau - tau_rev*k2 + N2)/self.ratio_a
        dk2 = (-self.ratio_a*k1_rev*tau + tau_rev*k1 - N1)/self.ratio_b
        dtau = self.ratio_a*k1_rev*k2 - self.ratio_b*k2_rev*k1
        # Moment
#        dM2 = (1.-self.ratio_a)*k1*tau - N1
#        dtau = -M2*k1
        # Quaternion
#        dq0 = 0.5*(-q1*k1 - q3*tau)
#        dq1 = 0.5*( q0*k1 + q2*tau)
#        dq2 = 0.5*( q3*k1 - q1*tau)
#        dq3 = 0.5*(-q2*k1 + q0*tau)
        dq0 = 0.5*(-q1*k1 - q2*k2 - q3*tau)
        dq1 = 0.5*( q0*k1 - q3*k2 + q2*tau)
        dq2 = 0.5*( q3*k1 + q0*k2 - q1*tau)
        dq3 = 0.5*(-q2*k1 + q1*k2 + q0*tau)
        # Position
        dx  = 2.*(q1*q3 + q0*q2)
        dy  = 2.*(q2*q3 - q0*q1)
        dz  = 2.*(q0*q0 + q3*q3 - 0.5)
        return np.vstack((dN1,dN2,dN3,dk1,dk2,dtau,dq0,dq1,dq2,dq3,dx,dy,dz))
    
    def BoundaryConditions(self, ya, yb):
        # States at s=0
#        N1_a = ya[0]
#        N2_a = ya[1]
#        N3_a = ya[2]
        k1_a  = ya[3]
        k2_a  = ya[4]
#        M2_a  = ya[4]
        tau_a = ya[5]
        q0_a  = ya[6]
        q1_a  = ya[7]
        q2_a  = ya[8]
        q3_a  = ya[9]
        x_a   = ya[10]
        y_a   = ya[11]
        z_a   = ya[12]
        # States at s=L
#        N1_b = yb[0]
#        N2_b = yb[1]
#        N3_b = yb[2]
        k1_b  = yb[3]
        k2_b  = yb[4]
#        M2_b  = yb[4]
        tau_b = yb[5]
        q0_b  = yb[6]
        q1_b  = yb[7]
        q2_b  = yb[8]
        q3_b  = yb[9]
        x_b   = yb[10]
        y_b   = yb[11]
        z_b   = yb[12]
        
        # q0,q1,q2,q3 = self.Euler2Quaternion(psi=0.5*np.pi, theta=0.5*np.pi, phi=self.psi0)
        q0,q1,q2,q3 = self.Euler2Quaternion(psi=0.001, theta=0.5*np.pi, phi=self.psi0)
        error = np.zeros(13)
        # State at x=a
        error[0]  = q0_a - q0
        error[1]  = q1_a - q1
        error[2]  = q2_a - q2
        error[3]  = q3_a - q3
        error[4]  = x_a
        error[5]  = y_a - self.R_hub/self.L_beam
        error[6]  = z_a
        # State at x=b
        q0,q1,q2,q3 = self.Euler2Quaternion(psi=0., theta=0.5*np.pi, phi=self.theta0)
        error[7]  = q1_b - q1
        error[8]  = q2_b - q2        
        error[9]  = q3_b - q3
        error[10] = x_b - self.height0
        error[11] = y_b - self.R_hub*np.cos(self.theta0)/self.L_beam
        error[12] = z_b - self.R_hub*np.sin(self.theta0)/self.L_beam
        return(error)

    def Euler2Quaternion(self, psi, theta, phi):
        q0 = np.cos(0.5*theta)*np.cos(0.5*(phi+psi))
        q1 = np.sin(0.5*theta)*np.sin(0.5*(phi-psi))
        q2 = np.sin(0.5*theta)*np.cos(0.5*(phi-psi))
        q3 = np.cos(0.5*theta)*np.sin(0.5*(phi+psi))
        return(q0,q1,q2,q3)
        
    def InitialConditions(self, x, fig_flag=False):
        y_guess = np.zeros((13, x.size))
        # N1
        y_guess[0,:] = 0.
        # N2
        y_guess[1,:] = 0.
        # N3
        y_guess[2,:] = 0.
        # k1
        y_guess[3,:] = 1e-3 #0.5*np.pi
        # k2
        y_guess[4,:] = self.k2_0
        # tau
        y_guess[5,:] = self.tau_0
        
        # q0_a,q1_a,q2_a,q3_a = self.Euler2Quaternion(psi=0.5*np.pi, theta=0.5*np.pi, phi=0.)
        q0_a,q1_a,q2_a,q3_a = self.Euler2Quaternion(psi=0.001, theta=0.5*np.pi, phi=0.)
        q0_b,q1_b,q2_b,q3_b = self.Euler2Quaternion(psi=0., theta=0.5*np.pi, phi=0.)
        # q0
        y_guess[6,:] = q0_a + (q0_b-q0_a)*x
        # q1
        y_guess[7,:] = q1_a + (q1_b-q1_a)*x
        # q2
        y_guess[8,:] = q2_a + (q2_b-q2_a)*x
        # q3
        y_guess[9,:] = q3_a + (q3_b-q3_a)*x
        # x
        y_guess[10,:] = (1.-np.cos(np.pi*x))/(np.pi)
        # y
        y_guess[11,:] = np.sin(np.pi*x)/(np.pi) + self.R_hub/self.L_beam
        # z
        y_guess[12,:] = 0.

        if fig_flag==True:
            fig = plt.figure('Initial guess')
            ax = fig.gca(projection='3d')
            ax.plot(y_guess[10,:], y_guess[11,:], y_guess[12,:], label='parametric curve')
            ax.set_xlabel('$x$')
            ax.set_ylabel('$y$')
            ax.set_zlabel('$z$')
        
#        plt.figure('2D shape')
#        plt.plot(y_guess[10,:], y_guess[11,:], 'b--')
#        plt.xlabel("x")
#        plt.ylabel("y")
        return(y_guess)
    
    def Save_VTK_file(self, result_bvp, height, theta, i_step):
        x_vtk   = np.linspace(0, 1, 2*self.N_s-1)
        sol_vtk = result_bvp.sol(x_vtk)
#        # Force
#        N1_sol  = result.sol(x_plot)[0]
        # Deformation
        k1_sol  = sol_vtk[3,:]
        k2_sol  = sol_vtk[4,:]
        tau_sol = sol_vtk[5,:]
        # Quaternion
        q0_sol = sol_vtk[6,:]
        q1_sol = sol_vtk[7,:]
        q2_sol = sol_vtk[8,:]
        q3_sol = sol_vtk[9,:]
        Q_vec  = np.vstack((q0_sol,q1_sol,q2_sol,q3_sol))
        # Position
        x_sol = sol_vtk[10,:]
        y_sol = sol_vtk[11,:]
        z_sol = sol_vtk[12,:]
        x_vec = np.vstack((x_sol,y_sol,z_sol))
        # Energy
        energy_dens = np.zeros((3,2*self.N_s-1))
        energy_dens[0,:] = (1.+self.nu_Poi)/(6.*self.l_shape)*(k1_sol-self.k1_0)**2
        energy_dens[1,:] = (1.+self.nu_Poi)/(6.*self.l_shape)*(self.aspect**2)*(k2_sol-self.k2_0)**2
        energy_dens[2,:] = (tau_sol-self.tau_0)**2
        # Save energy
        with open('{0}/Data_files/Energy_{1}.csv'.format(self.dir_cwd+'/'+self.dir_save, str(i_step).zfill(3)),'w') as f:
            f.write('Arch length, Energy(k1), Energy(k2), Energy(tau)\n')
            for i_s in range(2*self.N_s-1):
                f.write('{0}, {1}, {2}, {3}\n'.format(x_vtk[i_s], energy_dens[0,i_s], energy_dens[1,i_s], energy_dens[2,i_s]))
        # Export a VTK file
        for i_rod in range(self.Nsec_hub):
            self.CreateVTK(x_vec, Q_vec, k1_sol, k2_sol, tau_sol,
                           fname='TwistKirigami_VTK_Animation_rod{}'.format(i_rod),
                           rot_x1=2.*np.pi/self.Nsec_hub*i_rod, i_step=i_step)
        # Hub
        self.CreateVTK_Hub(height=0., rot_hub=0., fname='Hub_Bottom')
        self.CreateVTK_Hub(height=height, rot_hub=theta, fname='Hub_Top_{}'.format(i_step))
        return()
        
        
    def Analyze_bvp(self, height0, psi0, theta0, x, y_guess, bvp_output=True, fig_flag=True, vtk_flag=True, i_step=0):
        self.height0 = height0
        self.psi0    = psi0
        self.theta0  = theta0
        if bvp_output==True:
            verbose = 1
        else:
            verbose = 0
        result_bvp = solve_bvp(self.Equations_Kirchhoff, self.BoundaryConditions, x, y_guess,
                           max_nodes=self.max_nodes , verbose=verbose)
        
        x_plot = np.linspace(0, 1, 2*self.N_s-1)
        sol_plot = result_bvp.sol(x_plot)
        # Force
        N1_sol  = sol_plot[0,:]
        N2_sol  = sol_plot[1,:]
        N3_sol  = sol_plot[2,:]
        # Deformation
        k1_sol  = sol_plot[3,:]
        k2_sol  = sol_plot[4,:]
        tau_sol = sol_plot[5,:]
#        # Quaternion
#        q0_sol = result.sol(x_plot)[6]
#        q1_sol = result.sol(x_plot)[7]
#        q2_sol = result.sol(x_plot)[8]
#        q3_sol = result.sol(x_plot)[9]
#        Q_vec  = np.vstack((q0_sol,q1_sol,q2_sol,q3_sol))
#        # Position
#        x_sol = result.sol(x_plot)[10]
#        y_sol = result.sol(x_plot)[11]
#        z_sol = result.sol(x_plot)[12]
#        x_vec = np.vstack((x_sol,y_sol,z_sol))
        # Energy
        energy_dens = np.zeros((3,2*self.N_s-1))
        energy_dens[0,:] = (1.+self.nu_Poi)/(6.*self.l_shape)*(k1_sol-self.k1_0)**2
        energy_dens[1,:] = (1.+self.nu_Poi)/(6.*self.l_shape)*(self.aspect**2)*(k2_sol-self.k2_0)**2
        energy_dens[2,:] = (tau_sol-self.tau_0)**2
        
        energy_total =  energy_dens[0,:] + energy_dens[1,:] + energy_dens[2,:]
        energy = integrate.simps(energy_total, x_plot)
        if bvp_output==True:
            print('Converged: {}'.format(result_bvp.success))
        
        # Create VTK file
        if vtk_flag==True:
            self.Save_VTK_file(result_bvp, height0, theta0, i_step)
        
        # Figure
        if fig_flag==True:
            # Position
            x_sol = result_bvp.sol(x_plot)[10]
            y_sol = result_bvp.sol(x_plot)[11]
            z_sol = result_bvp.sol(x_plot)[12]
            x_vec = np.vstack((x_sol,y_sol,z_sol))
            fig = plt.figure()
            ax = fig.gca(projection='3d')
            ax.plot(x_vec[0,:], x_vec[1,:], x_vec[2,:], label='parametric curve')
            ax.set_xlabel('$x$')
            ax.set_ylabel('$y$')
            ax.set_zlabel('$z$')
            
            
            plt.figure('2D shape')
            plt.grid(True)
            plt.plot(y_sol, x_sol, 'r')
            plt.xlabel("y")
            plt.ylabel("x")
            
            plt.figure('Energy Density')
            plt.plot(x_plot, energy_dens[0,:], label='$\kappa_1$')
            plt.plot(x_plot, energy_dens[1,:], label='$\kappa_2$')
            plt.plot(x_plot, energy_dens[2,:], label='$\\tau$')
            plt.legend(loc='best')
            plt.xlabel("Arch length, $s$")
            plt.ylabel("Energy density")
            
            plt.figure('Force')
            plt.plot(x_plot, N2_sol, 'b')
            plt.xlabel("Arch length, $s$")
            plt.ylabel("Normal force, $N_2$")
        return(result_bvp, energy)
    
    def SearchInitialConfiguration(self, height0, beam_twist, vtk_flag=True):
        N_step  = len(beam_twist)
        x       = np.linspace(0, 1, self.N_s)
        y_guess = self.InitialConditions(x)
        
        bvp_results  = []
        bar_template = "\r[{0}] {1}/{2} step"
        n_prog       =  int(N_step/20)  
        print('===== Start searching initial configuration =====')
        for i_step in range(N_step):
            # Display progress
            bar = "#" * int(i_step/n_prog) + " " * int(20-i_step/n_prog)
            print(bar_template.format(bar, i_step, N_step), end="")
#            print('Beam twist angle = {0:.2f}'.format(np.degrees(beam_twist[i_step])))
            result_bvp,_ = self.Analyze_bvp(height0, psi0=beam_twist[i_step], theta0=0.,
                                                x=x, y_guess=y_guess, bvp_output=False,
                                                fig_flag=False, vtk_flag=vtk_flag, i_step=i_step)
            if result_bvp.success==False:
                bvp_results.append(i_step)
                break
            y_guess = result_bvp.sol(x)
        
        print('\nSummary: Failed calculation = {}'.format(len(bvp_results)))
        print('===== Finished initial configuration search! ===== ')
        print('\n')
        return(y_guess, bvp_results)
    
    def LocalCoordinate(self, Q_vec):
        d1_vec = np.zeros(3)
        d2_vec = np.zeros(3)
        q0 = Q_vec[0]
        q1 = Q_vec[1]
        q2 = Q_vec[2]
        q3 = Q_vec[3]
        # d1 vector
        d1_vec[0] = 2.*(q0*q0 + q1*q1 - 0.5)
        d1_vec[1] = 2.*(q1*q2 + q0*q3)
        d1_vec[2] = 2.*(q1*q3 - q0*q2)
        # d2 vector
        d2_vec[0] = 2.*(q1*q2 - q0*q3)
        d2_vec[1] = 2.*(q0*q0 + q2*q2 - 0.5)
        d2_vec[2] = 2.*(q2*q3 + q0*q1)
        return(d1_vec, d2_vec)
    
        
    def SingleElement(self, x0, x2, Q0, Q2):
        Vertex_cube = np.zeros((8,3))  # Vertex number, (x,y,z) coordinate
        
        W_half = self.width/(2.*self.L_beam)
        T_half = self.thick/(2.*self.L_beam)
        d1_vec0, d2_vec0 = self.LocalCoordinate(Q0)
        d1_vec2, d2_vec2 = self.LocalCoordinate(Q2)
        # Lower vertex ---------------------------------
        # Vertex 0
        Vertex_cube[0,:] = x0[:] - W_half*d1_vec0 - T_half*d2_vec0
        # Vertex 1
        Vertex_cube[1,:] = x0[:] + W_half*d1_vec0 - T_half*d2_vec0
        # Vertex 2
        Vertex_cube[2,:] = x2[:] + W_half*d1_vec2 - T_half*d2_vec2
        # Vertex 3
        Vertex_cube[3,:] = x2[:] - W_half*d1_vec2 - T_half*d2_vec2
        # Upper vertex ---------------------------------
        # Vertex 4
        Vertex_cube[4,:] = x0[:] - W_half*d1_vec0 + T_half*d2_vec0
        # Vertex 5
        Vertex_cube[5,:] = x0[:] + W_half*d1_vec0 + T_half*d2_vec0
        # Vertex 6
        Vertex_cube[6,:] = x2[:] + W_half*d1_vec2 + T_half*d2_vec2
        # Vertex 7
        Vertex_cube[7,:] = x2[:] - W_half*d1_vec2 + T_half*d2_vec2
        return(Vertex_cube)
    
    def Create_Script4Paraview(self, data_show):
        # Create a script for Paraview -----------------------
        fname_paraview = self.dir_cwd+'/Paraview_Animation_DoNotChange.py'
        txt_data = []
        with open(fname_paraview,'r') as f:
            f_list = f.readlines()
            i_Line = 0
            for line in f_list: # Read number of step
                # Detect vertex
                i_variable = line.find('#PY_VARIABLE')
                if i_variable >= 0:
                    if line.find('dir_vtk') >=0:
                        line_wrk = "dir_vtk = '{}'\n".format(self.dir_cwd+'/'+self.dir_save)
                    elif line.find('n_beam') >=0:
                        line_wrk = "n_beam = {}\n".format(self.Nsec_hub)
                    elif line.find('data_show') >=0:
                        line_wrk = "data_show = '{}'\n".format(data_show)
                    else:
                        line_wrk = line
                        print('Unkown variable !!!!!!!!!!!!!!!')
                else:
                    line_wrk = line
                # Store the line
                txt_data.append(line_wrk)
                # Renew
                i_Line = i_Line + 1
        
        # Write data into txt file
        fscript_save = self.dir_cwd+'/Paraview_Animation_use.py'
        with open(fscript_save,'w') as f:
            for i in range(len(txt_data)):
                f.write(txt_data[i])
        return()

    def CreateVTK(self, x_vec, Q_vec, k1, k2, tau, fname, rot_x1, i_step):
        N_ele = self.N_s-1
        # Rotation around x-axis
        R_x1 = np.array([[1., 0.,            0.],
                         [0., np.cos(rot_x1), -np.sin(rot_x1)],
                         [0., np.sin(rot_x1),  np.cos(rot_x1)] ])
        #Export text file
        
        with open('{0}/{1}_{2}.vtk'.format(self.dir_cwd+'/'+self.dir_save,
                                           fname, str(i_step).zfill(3)),'w') as f:
            f.write('# vtk DataFile Version 2.0\n')
            f.write('Cubic module\n')
            f.write('ASCII\n')
            num_points = 8*N_ele
            f.write('DATASET UNSTRUCTURED_GRID\n')
            f.write('POINTS {0:d} float\n'.format(num_points))
            for i_ele in range(N_ele):
                # Calculate the coordinates of each cube
                Vertex_cube = self.SingleElement(x0=x_vec[:,2*i_ele], x2=x_vec[:,2*i_ele+2],
                                                 Q0=Q_vec[:,2*i_ele], Q2=Q_vec[:,2*i_ele+2])
                
                # Vertex information
                for i_v in range(8):
                    vec_map = np.matmul(R_x1, Vertex_cube[i_v,:])
#                    f.write('{0} {1} {2}\n'.format(Vertex_cube[i_v,0],Vertex_cube[i_v,1],Vertex_cube[i_v,2]))
                    f.write('{0} {1} {2}\n'.format(vec_map[0],vec_map[1],vec_map[2]))
            # POLYGONS
            num_dataset = N_ele
            num_datanum = 9*N_ele
            f.write('CELLS {0:d} {1:d}\n'.format(num_dataset,num_datanum))
            for i_ele in range(N_ele):
                i0 = 8*i_ele
                f.write('8 {0} {1} {2} {3} {4} {5} {6} {7}\n'.format(0+i0,1+i0,2+i0,3+i0,4+i0,5+i0,6+i0,7+i0))
                
            # Cell type ==============================================
            f.write('CELL_TYPES {0:d}\n'.format(num_dataset))
            for i_ele in range(N_ele):
                f.write('12\n')
                
            # Property ===============================================
            f.write('CELL_DATA {0:d}\n'.format(num_dataset))
            # Curvature
            f.write('SCALARS k1 float\n')
            f.write('LOOKUP_TABLE default\n')
            for i_ele in range(N_ele):
                f.write('{0:f}\n'.format(k1[2*i_ele+1]))
            # Curvature
            f.write('SCALARS k2 float\n')
            f.write('LOOKUP_TABLE default\n')
            for i_ele in range(N_ele):
                f.write('{0:f}\n'.format(k2[2*i_ele+1]))
            # Torsion
            f.write('SCALARS tau float\n')
            f.write('LOOKUP_TABLE default\n')
            for i_ele in range(N_ele):
                f.write('{0:f}\n'.format(tau[2*i_ele+1]))
            # Energy density
            f.write('SCALARS energy_density float\n')
            f.write('LOOKUP_TABLE default\n')
            for i_ele in range(N_ele):
                e_dens = (1.+self.nu_Poi)/(6.*self.l_shape)*k1[2*i_ele+1]**2\
                       + (1.+self.nu_Poi)*(self.aspect**2)/(6.*self.l_shape)*k2[2*i_ele+1]**2\
                       + tau[2*i_ele+1]**2
                f.write('{0:f}\n'.format(e_dens))
        # End of exporting vtk-------------------------------------------------
        
        
        return()
    
    def CreateVTK_Hub(self, height, rot_hub, fname):
        angle_sec = 2.*np.pi/self.Nsec_hub
        # if fname.find('Top')>0:
        #     radius = 1.3*self.R_hub/np.cos(np.pi/self.Nsec_hub)
        # else:
        #     radius = self.R_hub/np.cos(np.pi/self.Nsec_hub)
        radius = 1.3*self.R_hub/np.cos(np.pi/self.Nsec_hub)
        #Export text file
        with open('{0}/{1}.vtk'.format(self.dir_cwd+'/'+self.dir_save, fname),'w') as f:
            f.write('# vtk DataFile Version 2.0\n')
            f.write('Center hubs\n')
            f.write('ASCII\n')
            num_points = 6*self.Nsec_hub
            f.write('DATASET UNSTRUCTURED_GRID\n')
            f.write('POINTS {0:d} float\n'.format(num_points))
            # Create wedges
            for i_sec in range(self.Nsec_hub):
                # Bottom center -----------------------------------------------
                if fname.find('Top')>0:
                    x_vertex = height
                else:
                    # x_vertex = height -0.6*self.width/self.L_beam
                    x_vertex = height
                f.write('{0} {1} {2}\n'.format(x_vertex, 0., 0.))
                # Bottom edge1
                y_vertex = radius*np.cos(0.5*angle_sec + angle_sec*i_sec + rot_hub)/self.L_beam
                z_vertex = radius*np.sin(0.5*angle_sec + angle_sec*i_sec + rot_hub)/self.L_beam
                f.write('{0} {1} {2}\n'.format(x_vertex,y_vertex,z_vertex))
                # Bottom edge1
                y_vertex = radius*np.cos(0.5*angle_sec + angle_sec*(i_sec+1) + rot_hub)/self.L_beam
                z_vertex = radius*np.sin(0.5*angle_sec + angle_sec*(i_sec+1) + rot_hub)/self.L_beam
                f.write('{0} {1} {2}\n'.format(x_vertex,y_vertex,z_vertex))
                
                # Top center -----------------------------------------------
                if fname.find('Top')>0:
                    x_vertex = height + 1.2*self.width/self.L_beam
                else:
                    # x_vertex = height + 0.6*self.width/self.L_beam
                    x_vertex = height - 1.2*self.width/self.L_beam
                f.write('{0} {1} {2}\n'.format(x_vertex, 0., 0.))
                # Top edge1
                y_vertex = radius*np.cos(0.5*angle_sec + angle_sec*i_sec + rot_hub)/self.L_beam
                z_vertex = radius*np.sin(0.5*angle_sec + angle_sec*i_sec + rot_hub)/self.L_beam
                f.write('{0} {1} {2}\n'.format(x_vertex,y_vertex,z_vertex))
                # Top edge1
                y_vertex = radius*np.cos(0.5*angle_sec + angle_sec*(i_sec+1) + rot_hub)/self.L_beam
                z_vertex = radius*np.sin(0.5*angle_sec + angle_sec*(i_sec+1) + rot_hub)/self.L_beam
                f.write('{0} {1} {2}\n'.format(x_vertex,y_vertex,z_vertex))

            # POLYGONS
            num_dataset = self.Nsec_hub
            num_datanum = 7*self.Nsec_hub
            f.write('CELLS {0:d} {1:d}\n'.format(num_dataset,num_datanum))
            for i_sec in range(self.Nsec_hub):
                i0 = 6*i_sec
                f.write('6 {0} {1} {2} {3} {4} {5}\n'.format(0+i0,1+i0,2+i0,3+i0,4+i0,5+i0))
            # Cell type ==============================================
            f.write('CELL_TYPES {0:d}\n'.format(num_dataset))
            for i_sec in range(self.Nsec_hub):
                f.write('13\n')  # 13=VTK_WEDGE
        # End of exporting vtk-------------------------------------------------
        return()
    
    def Analyze_Deformation(self, beam_twist, h_range, Rot_hub, height0=2./np.pi,
                            y_guess=[], fig_flag=True, vtk_flag=True, data_show='k1'):
        x = np.linspace(0, 1, self.N_s)
        y_guess = self.InitialConditions(x)
        # Find the initial configuration -----------------
        if len(y_guess)==0:
            y_guess,bvp_res = self.SearchInitialConfiguration(height0=height0, #h_range[0],
                                                              beam_twist=beam_twist,
                                                              vtk_flag=False)
            if len(bvp_res)>0:
                print('Not found initial configuration')
                return()
        # Apply controlled displacement ------------------
        N_step   = len(h_range)
        energy   = np.zeros(N_step)
        force_N2 = np.zeros((2,N_step))
        Q_vec    = np.zeros((4,N_step))
        bvp_results  = []
        bar_template = "\r[{0}] {1}/{2} step"
        n_prog       =  int(N_step/20)  
        print('===== Start searching deformation based on prescribed BCs =====')
        for i_step in range(N_step):
            # Display progress
#            print('(Height, Hub rotation) = ({0:.2f},{1:.2f})'.format(h_range[i_step],np.degrees(Rot_hub[i_step])) )
            bar = "#" * int(i_step/n_prog) + " " * int(20-i_step/n_prog)
            print(bar_template.format(bar, i_step, N_step), end="")
            # Solve BVP
            result_bvp,ene = self.Analyze_bvp(h_range[i_step], psi0=beam_twist[-1], theta0=Rot_hub[i_step],
                                                x=x, y_guess=y_guess, bvp_output=False,
                                                fig_flag=False, i_step=i_step)
            if result_bvp.success==False:
                bvp_results.append(i_step)
                break
            # Store the calculation results
            y_guess        = result_bvp.sol(x)
            energy[i_step] = ene
            force_N2[0,i_step] = y_guess[1,0]  # Force at the bottom
            force_N2[1,i_step] = y_guess[1,-1] # Froce at the top
#            # Quaternion
#            i_s = 0
#            Q_vec[0,i_step]    = x_sol[6,i_s]
#            Q_vec[1,i_step]    = x_sol[7,i_s]
#            Q_vec[2,i_step]    = x_sol[8,i_s]
#            Q_vec[3,i_step]    = x_sol[9,i_s]
#            d1_vec0, d2_vec0 = self.LocalCoordinate(Q_vec[:,i_step])
#            print(d2_vec0)
        print('\nSummary: Failed calculation = {}'.format(len(bvp_results)))
        print('===== Finish analyzing deformation =====')
        print('\n')
        
        # Results ---------------------------------------
        result = {'N2_top': force_N2[1,:],
                  'Energy': energy}
        i_enemin    = np.argmin(energy)
        self.fcomp  = force_N2[1,:]
        self.height = h_range
        self.height_enemin = h_range[i_enemin]
        if vtk_flag==True:
            self.Create_Script4Paraview(data_show)
        # Figure ----------------------------------------
        if fig_flag==True:
            
            plt.figure('Energy change')
            plt.plot(np.arange(N_step)+1, energy, 'b')
            plt.plot(i_enemin+1, energy[i_enemin], 'ro')
            plt.xlabel('Step')
            plt.ylabel('Energy')
            
            plt.figure('Force (N2)')
            plt.axhline(y=0, color='black', linewidth=2)
            plt.plot(np.arange(N_step)+1, force_N2[0,:], 'b', label='$N_2$ at bottom')
            plt.plot(np.arange(N_step)+1, force_N2[1,:], 'g--', label='$N_2$ at top')
            plt.plot(i_enemin+1, force_N2[1,i_enemin], 'ro')
            plt.legend(loc='best')
            plt.xlabel('Step')
            plt.ylabel('Force, $N_2$')
        return(result)
        
    def Search_Solution_FixedHeight(self, ix_step, iy_0, imin_prev, psi0, height, Rot_hub_range, y_guess_rot0, vtk_flag):
        x = np.linspace(0, 1, self.N_s)
        Ny_step  = len(Rot_hub_range)
        Energy   = np.zeros(Ny_step)
        N2_b     = np.zeros(Ny_step)
        Energy[:] = np.inf
        y_enemin = np.zeros((Ny_step,13,self.N_s))
        result   = {}
        # Increase the hub rotation from the energy minimum state ---------
        y_guess = y_guess_rot0
        for iy_step in range(iy_0, self.i_inf_pos):
            result_bvp,ene = self.Analyze_bvp(height0 = height,
                                                    psi0    = psi0,
                                                    theta0  = Rot_hub_range[iy_step], 
                                                    x=x, y_guess=y_guess, 
                                                    bvp_output=False, fig_flag=False, vtk_flag=False)
#                y_enemin.append(x_sol)
            y_enemin[iy_step,:,:] = result_bvp.sol(x)
            if vtk_flag==True:
                result[iy_step] = copy.deepcopy(result_bvp)
            if result_bvp.success==False:
                self.bvp_results.append([ix_step,10000+iy_step])
                self.i_inf_pos = iy_step
                break
            else:
                Energy[iy_step] = ene
                y_guess = y_enemin[iy_step,:,:]
                N2_b[iy_step] = y_guess[1,-1] # Froce at the top
            
        # Decrease the hub rotation from the energy minimum state ---------
        y_guess = y_guess_rot0
        for iy_step in range(iy_0-1,self.i_inf_neg,-1):
            result_bvp,ene = self.Analyze_bvp(height0 = height,
                                              psi0    = psi0,
                                              theta0  = Rot_hub_range[iy_step], 
                                              x=x, y_guess=y_guess,
                                              bvp_output=False, fig_flag=False, vtk_flag=False)
            y_enemin[iy_step,:,:] = result_bvp.sol(x)
            if vtk_flag==True:
                result[iy_step] = copy.deepcopy(result_bvp)
            if result_bvp.success==False:
                self.bvp_results.append([ix_step,20000+iy_step])
                self.i_inf_neg = iy_step-1
                break
            else:
                Energy[iy_step] = ene
                y_guess = y_enemin[iy_step,:,:]
                N2_b[iy_step] = y_guess[1,-1] # Froce at the top
        # Find local minimum of energy at fixed height --------------------
        
        minid = signal.argrelmin(Energy, order=1)
        n_min = len(minid[0])
        if n_min>1:
            diff = np.zeros(n_min)
            for i in range(n_min):
                diff[i] = abs(imin_prev-minid[0][i])
            ii = np.argmin(diff)
            i_min = minid[0][ii]
        elif n_min==0:
            i_min = np.argmin(Energy)
            if i_min==0 and Energy[0]==np.inf:
                vtk_flag=False
                print('\nCannot find a solution Orz...')
        else:
            i_min = minid[0][0]
        
        # Renew the guess for the next iteration --------------------------
        y_guess_rot0 = y_enemin[iy_0,:,:]
        # Create VTK file -------------------------------------------------
        if vtk_flag==True:
            self.Save_VTK_file(result_bvp=result[i_min], height=height,
                               theta=Rot_hub_range[i_min], i_step=ix_step)
        return(i_min, minid, Energy, N2_b, y_guess_rot0)
    
    def Analyze_2DEnergyLandscape(self,  beam_twist, h_range, Rot_hub_range, height0=2./np.pi, Rot_hub=[],
                                  vtk_flag=True, fig_flag=True, flag_contour=False, 
                                  vmax=None, vmin=None, data_show='k1'):
#        x = np.linspace(0, 1, self.N_s)
        Nx_step = len(h_range)
        Ny_step = len(Rot_hub_range)
        # Find the initial configuration -----------------
        ix_0 = 0
        for ix_step in range(Nx_step):
            if h_range[ix_step]<=height0:
                ix_0 = ix_step
                break
        y_guess_rot0,bvp_res = self.SearchInitialConfiguration(height0=height0,
                                                               beam_twist=beam_twist,
                                                               vtk_flag=False)
        if len(bvp_res)>0:
            print('Not found initial configuration')
            return()
        # Apply controlled displacement ------------------
        Energy = np.zeros((Nx_step, Ny_step))
        Energy[:,:]   = np.inf
        if len(Rot_hub)==0:
            Rot_hub    = np.zeros(Nx_step)
            Rot_enemin    = []
            find_enemin   = True
        else:
            find_enemin = False
        Energy_valley = np.zeros(Nx_step)
        N2_valley_top = np.zeros(Nx_step)
        iy_minum      = int(Ny_step/2)
        # for displaying progress bar
        self.bvp_results  = []
        bar_template = "\r[{0}] {1}/{2} iterations"   
        n_prog       =  int(Nx_step/20)
        print('===== Start sweeping configuration space =====')
        print('Beam twist angle = {0:.2f} deg'.format(np.degrees(beam_twist[-1])))
        
        # Tension =========================================================
        y_wrk = y_guess_rot0
        imin_prev = iy_minum
#        flag_inf  = []
        self.i_inf_pos = Ny_step
        self.i_inf_neg = -1
        for ix_step in range(ix_0-1,-1,-1):
            # Display progress
            bar = "#" * int((ix_0-ix_step)/n_prog) + " " * int(20-(ix_0-ix_step)/n_prog)
            print(bar_template.format(bar, ix_0-ix_step, Nx_step), end="")
            # Change the hub rotation and find energy minimum state
            i_min,minid,ene_wrk,N2_wrk,y_wrk = self.Search_Solution_FixedHeight(ix_step, iy_0=iy_minum, imin_prev=imin_prev,
                                                                          psi0=beam_twist[-1],
                                                                          height=h_range[ix_step],
                                                                          Rot_hub_range=Rot_hub_range,
                                                                          y_guess_rot0=y_wrk, vtk_flag=vtk_flag)
            Energy[ix_step, :] = ene_wrk
            imin_prev          = i_min
            # Terminate the calculation if we couldn't find solutions several times
            wrk = np.where(ene_wrk==np.inf)
            if len(wrk[0])==Ny_step:
                break
#            if len(wrk[0])>0:
#                if len(flag_inf)>0:
#                    break
#                else:
#                    flag_inf.append(True)
            # Find local minimum of energy at fixed height -------------------
            if find_enemin==True:
                Rot_hub[ix_step]    = Rot_hub_range[i_min]
                Energy_valley[ix_step] = Energy[ix_step, i_min]
                N2_valley_top[ix_step] = N2_wrk[i_min]
                for i in range(len(minid[0])):
                    Rot_enemin.append([h_range[ix_step],Rot_hub_range[minid[0][i]]])
            # Find local minimum state at the initial height ------------------
#            iy_minum = i_min
#            if ix_step==ix_0-1:
#                iy_minum = i_min
        # Compression =========================================================
        y_wrk = y_guess_rot0
        self.i_inf_pos = Ny_step
        self.i_inf_neg = -1
        for ix_step in range(ix_0, Nx_step):
            # Display progress
            bar = "#" * int(ix_step/n_prog) + " " * int(20-ix_step/n_prog)
            print(bar_template.format(bar, ix_step, Nx_step), end="")
            # Change the hub rotation and find energy minimum state
            i_min,minid,ene_wrk,N2_wrk,y_wrk = self.Search_Solution_FixedHeight(ix_step, iy_0=iy_minum, imin_prev=imin_prev,
                                                                          psi0=beam_twist[-1],
                                                                          height=h_range[ix_step],
                                                                          Rot_hub_range=Rot_hub_range,
                                                                          y_guess_rot0=y_wrk, vtk_flag=vtk_flag)
            Energy[ix_step, :] = ene_wrk
            imin_prev          = i_min
            # Find local minimum of energy at fixed height -------------------
            if find_enemin==True:
                Rot_hub[ix_step]    = Rot_hub_range[i_min]
                Energy_valley[ix_step] = Energy[ix_step, i_min]
                N2_valley_top[ix_step] = N2_wrk[i_min]
                for i in range(len(minid[0])):
                    Rot_enemin.append([h_range[ix_step],Rot_hub_range[minid[0][i]]])
            # Find local minimum state at the initial height ------------------
#            if ix_step==ix_0:
#                iy_minum = i_min
        print('\n Done !')
        print('Summary: Failed calculation = {}'.format(len(self.bvp_results)))
        print('===== Finished sweeping configuration space =====')
        print('\n')
        # Results ---------------------------------------
#        i_enemin   = np.argmin(Energy_valley)
        self.fcomp = N2_valley_top
#        self.displ_comp = h_range/h_range[i_enemin]
        self.height = h_range
#        self.height_enemin = h_range[i_enemin]
        if vtk_flag==True:
            self.Create_Script4Paraview(data_show)
        # Find local minima ----------------------------
        local_min = self.detect_local_minima(Energy)
        maxid = signal.argrelmax(Energy_valley, order=2)
        list_min  = []
        # Find saddle point
        if len(local_min[0])>2:
            N_max = 0
            for i in range(len(local_min[0])):
                diff = (local_min[0][i]==maxid[0])
                result = np.where(diff == True)
                if len(result[0])>0:
                    N_max = N_max+1
                else:
                    list_min.append([local_min[0][i], local_min[1][i]])
            N_min = len(list_min)
        else:
            N_min = len(local_min[0])
            for i in range(N_min):
                list_min.append([local_min[0][i], local_min[1][i]])
        print('Number of local minima = {}'.format(N_min))
        # Store data for comparison
        self.height_enemin = h_range[list_min[0][0]]
        self.hub_rot       = Rot_hub
        if find_enemin==True:
            self.energy_diff   = Energy_valley - Energy_valley[list_min[0][0]]
        else:
            result = self.Analyze_Deformation(beam_twist, h_range, Rot_hub,
                                              height0=h_range[0], data_show='k2', fig_flag=False ) #data_show='k1','k2','tau','energy_density'
        # Figure ==============================================================
        if fig_flag==True:
            # 2D energy plot --------------------------------------------------
            data_ana = "Energy_KirchhoffModel.csv" 
            with open(self.dir_cwd+'/'+data_ana,'w') as f:
                f.write("Hub rotation (deg), Normalized height (-), Normalized energy (-)\n")
                for ix_step in range(Nx_step):
                    for iy_step in range(Ny_step):
                        f.write("%f,%f,%f\n"%(np.degrees(Rot_hub_range[iy_step]),h_range[ix_step],Energy[ix_step,iy_step]) )
            self.csv2vtk(filename=self.dir_cwd+'/'+data_ana, Nx_max=Nx_step,
                         Ny_max=Ny_step, ColormapScale=np.amax(Energy))
    
            # Save energy along the valley
            with open('{0}/Data_files/Energy_Valley.csv'.format(self.dir_cwd+'/'+self.dir_save),'w') as f:
                f.write('Step, Height, Normalized total energy\n')
                for i_h in range(Nx_step):
                    f.write('{0}, {1}, {2}\n'.format(i_h, h_range[i_h], Energy_valley[i_h]))
            
            # Figures -----------------------------------------
            dx = abs(h_range[1]-h_range[0])
            dy = abs(Rot_hub_range[1]-Rot_hub_range[0])
            X,Y = np.meshgrid(h_range, np.degrees(Rot_hub_range))
            if vmax==None:
                vmax = np.amax(Energy[Energy != np.inf])
            if vmin==None:
                vmin = np.amin(Energy)
            plt.figure('Energy')
            plt.title('Beam twist angle = {0:.1f}$^\circ$'.format(np.degrees(beam_twist[-1])))
            plt.imshow(np.transpose(Energy), aspect='auto', origin='lower', 
                       cmap=plt.cm.afmhot, interpolation='none',
                       vmin=vmin, vmax=vmax,
                       extent=[h_range[0]+0.5*dx, h_range[-1]-0.5*dx,
                               np.degrees(Rot_hub_range[0]-0.5*dy), np.degrees(Rot_hub_range[-1]+0.5*dy)])
            plt.plot(h_range, np.degrees(Rot_hub), color='grey')
            # Draw energy valley
            if find_enemin==True:
                for i in range(len(Rot_enemin)):
                    plt.plot(Rot_enemin[i][0], np.degrees(Rot_enemin[i][1]), marker='.', color='m')
                # Plot localmimina
                for i in range(N_min):
                    plt.plot(h_range[list_min[i][0]], np.degrees(Rot_hub_range[list_min[i][1]]), 'co')
            cbar = plt.colorbar()
            cbar.solids.set_edgecolor("face")
            cbar.set_label('Normalized energy, $U$')
            # Contour lines
            if flag_contour==True:
                plt.contour(X, Y, np.transpose(Energy),
#                            levels = 18,
                            linewidths=1,colors='grey',linestyles='-')
            plt.xlabel('Height, $H/L$')
            plt.ylabel('Hub rotation, $\\theta$ (deg)')
            
            
            
            plt.figure('Energy curve along the valley')
            if find_enemin==True:
                plt.plot(h_range, Energy_valley, 'b')
                # Plot localmimina
                for i in range(N_min):
                    plt.plot(h_range[list_min[i][0]], Energy_valley[list_min[i][0]], 'v', color='k', markersize=18)
            else:
                plt.plot(h_range, result['Energy'], 'b')
            plt.xlabel('Height, $H/L$')
            plt.ylabel('Normalized energy, $E$')
            plt.xlim(h_range[0], h_range[-1])
            
            plt.figure('Force (N2) along the valley')
            if find_enemin==True:
                plt.plot(h_range, N2_valley_top, 'bo-')
                plt.plot(self.height_enemin, N2_valley_top[list_min[0][0]], 'co')
            else:
                plt.plot(h_range, result['N2_top'], 'bo-')
            plt.xlabel('Height, $H/L$')
            plt.ylabel('Normalized force at top, $N_2$')
            plt.xlim(h_range[0], h_range[-1])
        return(Energy_valley, N_min, Energy)
    
    def detect_local_minima(self, arr, size=5):
        # https://stackoverflow.com/questions/3684484/peak-detection-in-a-2d-array/3689710#3689710
        """
        Takes an array and detects the troughs using the local maximum filter.
        Returns a boolean mask of the troughs (i.e. 1 when
        the pixel's value is the neighborhood maximum, 0 otherwise)
        """
        
        # define an connected neighborhood
        # http://www.scipy.org/doc/api_docs/SciPy.ndimage.morphology.html#generate_binary_structure
        neighborhood = morphology.generate_binary_structure(len(arr.shape),2)
        # we create the mask of the background
        background = (arr==np.inf)
        # a little technicality: we must erode the background in order to 
        # successfully subtract it from local_min, otherwise a line will 
        # appear along the background border (artifact of the local minimum filter)
        # http://www.scipy.org/doc/api_docs/SciPy.ndimage.morphology.html#binary_erosion
        eroded_background = morphology.binary_erosion(
            background, structure=neighborhood, border_value=1)
        
        # apply the local minimum filter; all locations of minimum value 
        # in their neighborhood are set to 1
        # http://www.scipy.org/doc/api_docs/SciPy.ndimage.filters.html#minimum_filter
        local_min1 = (filters.minimum_filter(arr, footprint=neighborhood)==arr)
        local_min2 = (filters.minimum_filter(arr, size=size)==arr)
        # Remove np.inf and extract overlaps
        local_min = np.bitwise_and(np.bitwise_xor(local_min1, eroded_background),
                                   np.bitwise_xor(local_min2, eroded_background))
        # local_min is a mask that contains the peaks we are 
        # looking for, but also the background.
        # In order to isolate the peaks we must remove the background from the mask.
        
#        # we create the mask of the background
#        background = (arr==np.inf)
#        # a little technicality: we must erode the background in order to 
#        # successfully subtract it from local_min, otherwise a line will 
#        # appear along the background border (artifact of the local minimum filter)
#        # http://www.scipy.org/doc/api_docs/SciPy.ndimage.morphology.html#binary_erosion
#        eroded_background = morphology.binary_erosion(
#            background, structure=neighborhood, border_value=1)
        # we obtain the final mask, containing only peaks, 
        # by removing the background from the local_min mask
#        detected_minima = np.bitwise_xor(local_min, eroded_background)
        return np.where(local_min)  

    def csv2vtk(self,filename, Nx_max, Ny_max, ColormapScale):
        with open(filename,'r') as f:
            f.readline()
            
            x = []
            y = []
            value = []
            for line0 in f:
                line = line0[0:len(line0)-1]
                item = line.split(",")
                x.append(item[0])
                y.append(item[1])
                value.append(item[2])
            f.close()
            # output
            basename = os.path.splitext(filename)[0]
            f = open(basename + ".vtk", "w")
            f.write("# vtk DataFile Version 2.0\n")
            f.write(basename + "\n")
            f.write("ASCII\n")
            f.write("DATASET UNSTRUCTURED_GRID\n")
            f.write("POINTS %d float\n" % len(x))
            num = len(x)
            for i in range(0, num):
                f.write(x[i] + " " + y[i] + " 0\n")
            f.write("CELLS %d %d\n" % (num, 2*num))
            for i in range(0, num):
                f.write("1 %d\n" % i)
            f.write("CELL_TYPES %d\n" % num)
            for i in range(0, num):
                f.write("1\n")
            f.write("POINT_DATA %d\n" % num)
            f.write("SCALARS point_scalars float\n")
            f.write("LOOKUP_TABLE default\n")
            for i in range(0, num):
                f.write(value[i] + "\n")
        # Create a script for Paraview -----------------------
        fname_paraview = self.dir_cwd+'/Paraview_SurfacePlot_DoNotChange.py'
        txt_data = []
        with open(fname_paraview,'r') as f:
            f_list = f.readlines()
            i_Line = 0
            for line in f_list: # Read number of step
                # Detect vertex
                i_variable = line.find('#PY_VARIABLE')
                if i_variable >= 0:
                    if line.find('fname_ext') >=0:
                        line_wrk = "fname_ext = '{}.vtk'\n".format(basename)
                    elif line.find('Nx_max') >=0:
                        line_wrk = "Nx_max = {}\n".format(Nx_max)
                    elif line.find('Ny_max') >=0:
                        line_wrk = "Ny_max = {}\n".format(Ny_max)
                    elif line.find('ColormapScale') >=0:
                        line_wrk = "ColormapScale = {}\n".format(ColormapScale)
                    else:
                        line_wrk = line
                        print('Unkown variable !!!!!!!!!!!!!!!')
                else:
                    line_wrk = line
                # Store the line
                txt_data.append(line_wrk)
                # Renew
                i_Line = i_Line + 1
        
        # Write data into txt file
        fscript_save = self.dir_cwd+'/Paraview_SurfacePlot_use.py'
        with open(fscript_save,'w') as f:
            for i in range(len(txt_data)):
                f.write(txt_data[i])
        return()
    
    def Temp(self, beam_twist, h_range, Rot_hub_range):
        Energy = np.load('Energy_180.npy')
        Energy_valley = np.load('Energy_valley_180.npy')
#        Energy = np.load('energy_124.npy')
#        Energy_valley = np.load('Energy_valley_124.npy')
        Nx = len(Energy[:,0])
        Ny = len(Energy[:,1])
        for ix_step in range(Nx):
            wrk = np.where(Energy[ix_step, :]==np.inf)
            if len(wrk[0])==Ny:
                print('detected')
        # Find local minima ----------------------------
        local_min = self.detect_local_minima(Energy)
        maxid = signal.argrelmax(Energy_valley, order=2)
        list_min  = []
        # Find saddle point
        if len(local_min[0])>2:
            N_max = 0
            for i in range(len(local_min[0])):
                diff = (local_min[0][i]==maxid[0])
                result = np.where(diff == True)
                if len(result[0])>0:
                    N_max = N_max+1
                else:
                    list_min.append([local_min[0][i], local_min[1][i]])
            N_min = len(list_min)
        else:
            N_min = len(local_min[0])
            for i in range(N_min):
                list_min.append([local_min[0][i], local_min[1][i]])
        print('Number of local minima = {}'.format(N_min))
            
        # Figures -----------------------------------------
        dx = abs(h_range[1]-h_range[0])
        dy = abs(Rot_hub_range[1]-Rot_hub_range[0])
        vmax = np.amax(Energy[Energy != np.inf])
        vmin = np.amin(Energy)
        print(vmax)
        print(vmin)
        plt.figure('Energy')
        plt.title('Beam twist angle = {0:.1f}$^\circ$'.format(np.degrees(beam_twist[-1])))
        plt.imshow(np.transpose(Energy), aspect='auto', origin='lower', 
                   cmap=plt.cm.afmhot, interpolation='none',
                   vmax= vmax, vmin=vmin,
                   extent=[h_range[0]+0.5*dx, h_range[-1]-0.5*dx,
                           np.degrees(Rot_hub_range[0]-0.5*dy), np.degrees(Rot_hub_range[-1]+0.5*dy)])
#        plt.plot(h_range, np.degrees(Rot_valley), color='grey')
#        for i in range(len(Rot_enemin)):
#            plt.plot(Rot_enemin[i][0], np.degrees(Rot_enemin[i][1]), marker='.', color='m')
        # Plot localmimina
        for i in range(N_min):
            plt.plot(h_range[list_min[i][0]], np.degrees(Rot_hub_range[list_min[i][1]]), 'co')
        cbar = plt.colorbar()
        cbar.solids.set_edgecolor("face")
        cbar.set_label('Normalized energy, $U$')  
        plt.xlabel('Height, $H/L$')
        plt.ylabel('Hub rotation, $\\theta$ (deg)')
        
        plt.figure('Energy curve along the valley')
        plt.plot(h_range, Energy_valley, 'b')
        # Plot localmimina
        for i in range(N_min):
            plt.plot(h_range[list_min[i][0]], Energy_valley[list_min[i][0]], 'co')
        for ii in range(len(maxid[0])):
            plt.plot(h_range[maxid[0][ii]], Energy_valley[maxid[0][ii]], 'ro')
        plt.xlabel('Height, $H/L$')
        plt.ylabel('Normalized energy, $E$')
        plt.xlim(h_range[0], h_range[-1])
        return()
    
if __name__ == "__main__":
    # =========================================================================
    # Input information
    # =========================================================================
    # Geometrical parameter
    thick  = 3.*1e-3   # [m]: Thickness of the beam
    width  = 5.*1e-3   # [m]: Height of the beam
    L_beam = 60.*1e-3  # [m]: Length of the beam
    R_hub  = 10.*1e-3  # [m]: Radius of the hub
    Nsec_hub = 6       # Number of sides for the hub
    k1_0   = 0.        # Initial k1 value
    k2_0   = 0.        # Initial k2 value
    tau_0  = 0.        # Initial tau value
    # Material property
    Eyng   = 2.389905e+06  # [Pa]: Young's modulus of PDMS (Based on optimization)
    nu_Poi = 0.45      # Poisson's ratio
    N_s    = 200
    # Directory where the calculation results are saved
    fname   ='TwistKirigami_rod_Perpendicular'
    dir_cwd = os.getcwd()
    
    flexrod = Static_KirchhoffRod_perpendicular(thick, width, L_beam, R_hub, Nsec_hub,
                                                k1_0, k2_0, tau_0,
                                                Eyng, nu_Poi, fname, dir_cwd, N_s)
    
    # =========================================================================
    # Solve boundary value problems
    # =========================================================================
    height0      = 0.999
    # Single calculation -----------------------------------------------
    # x = np.linspace(0, 1, N_s)
    # y_guess      = flexrod.InitialConditions(x)
    # beam_twist   = np.radians(0)
    # rot_hub      = np.radians(0)
    # result_bvp,energy = flexrod.Analyze_bvp(height0, psi0=beam_twist, theta0=rot_hub, x=x, y_guess=y_guess)

    
    # Analyze deformation sequence -------------------------------------
    beam_twist = np.linspace(0., np.radians(0), 100)
    N_step     = 65    
    # Compression along a designed trajectory
    # (HY: Peter, please modify h_range and Rot_hub based on your stem design) 
    h_range = np.linspace(height0, 0.25, N_step)    # Height change
    Rot_hub = np.linspace(0, np.radians(30), N_step) # Hub rotation
    
    N1      = 20
    N2      = 30
    N3      = 40
    N_step  = N1 + N2 + N3
    twist0  = np.radians(50)
    twist1  = np.radians(80)
    h_range = np.zeros(N_step)
    Rot_hub = np.zeros(N_step)
    for i in range(N_step):
        if i < N1:
            h_range[i] = height0 - i/float(N1)*0.3
            Rot_hub[i] = 0.
        elif i >= N1 and i< N1+N2:
            h_range[i] = height0 - 0.3
            Rot_hub[i] = (i-N1)/float(N2)*twist0
        else:
            h_range[i] = height0 - 0.3 - (i-N1-N2)/float(N3)*0.5
            Rot_hub[i] = twist0 - (i-N1-N2)/float(N3)*twist1
    plt.figure('Trajectory')
    plt.plot(h_range, np.degrees(Rot_hub), 'ro-')
    plt.xlim(h_range[0], h_range[-1])
    plt.xlabel('Height')
    plt.ylabel('Hub rotation')
    result  = flexrod.Analyze_Deformation(beam_twist, h_range, Rot_hub,
                                          height0=height0, data_show='k2') #data_show='k1','k2','tau','energy_density'
    
    

    # Construct surface energy plot ----------------------------------
    # beam_twist = np.linspace(0., np.radians(0), 180)
    # Nx_step    = 65 #90
    # Ny_step    = 121
    # # Compression
    # Rot_hub_range = np.linspace(-np.radians(15), np.radians(15), Ny_step)
    
    # # (HY: Peter, please modify h_range and Rot_hub based on your stem design) 
    # h_range = np.linspace(height0, 0.25, Nx_step) # Height change
    # Rot_hub = np.linspace(0, np.radians(15), N_step) # Hub rotation
    # Energy_valley, N_local, Energy = flexrod.Analyze_2DEnergyLandscape(beam_twist, h_range, Rot_hub_range, Rot_hub=Rot_hub,
    #                                                                     height0=height0, flag_contour=True, data_show='k1')

