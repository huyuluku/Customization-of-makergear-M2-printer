import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from scipy.integrate import solve_bvp
from scipy import integrate
from scipy import signal
import os
import shutil   #High level file operation
import time
import sys
from KirchhoffRodModel_bvp import Static_KirchhoffRod

# Figure parameters =================================================
# When you insert the figure, you need to make fig height 2
plt.rcParams['font.family']     = 'sans-serif'
plt.rcParams['figure.figsize']  = 8, 6      # (w=3,h=2) multiply by 3
plt.rcParams['font.size']       = 24        # Original fornt size is 8, multipy by above number
#plt.rcParams['text.usetex']     = True
#plt.rcParams['ps.useafm'] = True
#plt.rcParams['pdf.use14corefonts'] = True
#plt.rcParams['text.latex.preamble'] = '\usepackage{sfmath}'
plt.rcParams['lines.linewidth'] = 3.   
plt.rcParams['lines.markersize'] = 8. 
plt.rcParams['legend.fontsize'] = 20        # Original fornt size is 8, multipy by above number
plt.rcParams['xtick.labelsize'] = 24        # Original fornt size is 8, multipy by above number
plt.rcParams['ytick.labelsize'] = 24        # Original fornt size is 8, multipy by above number
plt.rcParams['xtick.direction'] = 'in'
plt.rcParams['ytick.direction'] = 'in' 
plt.rcParams['figure.subplot.left']  = 0.2
#plt.rcParams['figure.subplot.right']  = 0.7
plt.rcParams['figure.subplot.bottom']  = 0.2
plt.rcParams['savefig.dpi']  = 300


#==============================================================================
# Model the beam of twist kirigami structure as a Kirchhoff rod
#==============================================================================
class TwistKirigami_StabilityAnalysis:
    def __init__(self, thick, width, R_hub, Nsec_hub,
                 Eyng, nu_Poi, fname, dir_cwd, N_s):
        self.thick  = thick
        self.width  = width
        self.R_hub  = R_hub
        self.Nsec_hub = Nsec_hub
        self.Eyng   = Eyng
        self.nu_Poi = nu_Poi
        self.N_s    = N_s
        # Directory where the calculation results are saved
        self.fname      = fname
        self.dir_cwd    = dir_cwd
        self.dir_save   = 'TwistKirigami_VTK_Animation'
        # Parameters for the BVP solver
        self.max_nodes  = 10000

    def PhaseDiagram(self, beam_twist_range, thick_range, L_beam, Nx_step, Ny_step):
        
        N_twist         = len(beam_twist_range)
        N_thick          = len(thick_range)
        num_LocalMinima = np.zeros((N_thick,N_twist))
        
        # Save calculation results
        with open('StabilityAnalysisResults.csv','w') as f:
            f.write('Thickness of the beam (m), Beam twist angle (rad), Number of local minima\n')
        
        # Start iterations ----------------------------------------------------
        for i_thick in range(N_thick):
            flexrod = Static_KirchhoffRod(thick_range[i_thick], self.width, L_beam, self.R_hub, self.Nsec_hub,
                                  self.Eyng, self.nu_Poi, self.fname, self.dir_cwd, self.N_s, delete_data=False)
            for i_twist in range(N_twist):
                # Construct surface energy plot -------------------------------
                beam_twist = np.linspace(0., beam_twist_range[i_twist], 180)
                # Compression
                h_range       = np.linspace(2.5/np.pi, 0.4/np.pi, Nx_step)
#                h_range       = np.linspace(2.4/np.pi, 0., Nx_step) # This is for journal
                Rot_hub_range = np.linspace(-np.radians(80), np.radians(80), Ny_step)
                Energy_valley,N_local,_ = flexrod.Analyze_2DEnergyLandscape(beam_twist, h_range,
                                                                           Rot_hub_range, height0=2./np.pi,
                                                                           fig_flag=False, vtk_flag=False)
                num_LocalMinima[i_thick,i_twist] = N_local
#                # Find local minimum points
#                minid = signal.argrelmin(Energy_valley, order=1)
#                if len(minid[0])==0:
#                    maxid = signal.argrelmax(Energy_valley, order=1)
#                    if len(maxid[0])==1:
#                        num_LocalMinima[i_thick,i_twist] = 2
#                    else:
#                        num_LocalMinima[i_thick,i_twist] = 1
#                elif len(minid[0])==1:
#                    maxid = signal.argrelmax(Energy_valley, order=1)
#                    if len(maxid[0])==1:
#                        num_LocalMinima[i_thick,i_twist] = 2
#                    else:
#                        num_LocalMinima[i_thick,i_twist] = 1
#                else:
#                    num_LocalMinima[i_thick,i_twist] = len(minid[0])
        #        num_LocalMinima[i_q,i_t] = len(minid[0])
            # Save calculation results
            with open('StabilityAnalysisResults.csv','a') as f:
                for i_twist in range(N_twist):
                    f.write('{0}, {1}, {2}\n'.format(thick_range[i_thick],
                                                     beam_twist_range[i_twist],
                                                     num_LocalMinima[i_thick,i_twist]))
        
        # Figures =============================================================
#        plt.figure('Energy curve along the valley')
#        plt.plot(h_range, Energy_valley, 'b')
#        plt.xlabel('Height, $H/L$')
#        plt.ylabel('Normalized energy, $E$')
        
        plt.figure('Number of local minimum points')
        plt.plot(np.degrees(beam_twist_range), num_LocalMinima[0,:], 'bo')
        plt.plot(np.degrees(beam_twist_range), num_LocalMinima[1,:], 'ro')
        plt.xlabel('Beam twist angle, $\phi$ (deg)')
        plt.ylabel('# of minima')
                   
        dx = beam_twist_range[1] - beam_twist_range[0]
        dy = thick_range[1] - thick_range[0]
        plt.figure('Phase diagram', figsize=(24, 8))  # For journal figsize=(12, 8)
        plt.imshow(num_LocalMinima, aspect = 'auto',cmap=plt.cm.Paired, origin='lower',interpolation='nearest',
#                   vmin=1.25,
                   vmax=6,
                   extent=[np.degrees(beam_twist_range[0]-0.5*dx), np.degrees(beam_twist_range[-1]+0.5*dx),
                           (thick_range[0]-0.5*dy)/self.width, (thick_range[-1]+0.5*dy)/self.width]
                   )
        # Prototype configuration
        markersize = 18
#        plt.plot(np.radians(90), 60*1e-3,'ko',markersize=markersize)
        # Label
        plt.xlabel("Beam twist angle, $\phi$ (deg)")
        plt.ylabel("Thickness to width ratio, $h/w$")
        return()
    
    
if __name__ == "__main__":
    # =========================================================================
    # Input information
    # =========================================================================
    # Geometrical parameter
    thick  = 1.*1e-3   # [m]: Thickness of the beam
    width  = 5.*1e-3   # [m]: Height of the beam
    R_hub  = 10.*1e-3  # [m]: Radius of the hub
    Nsec_hub = 6       # Number of sides for the hub
    # Material property
    Eyng   = 2.389905e+06  # [Pa]: Young's modulus of PDMS (Based on optimization)
    nu_Poi = 0.45      # Poisson's ratio
    N_s    = 200
    # Directory where the calculation results are saved
    fname   ='TwistKirigami_rod'
    dir_cwd = os.getcwd()
    
    stability = TwistKirigami_StabilityAnalysis(thick, width, R_hub, Nsec_hub,
                                  Eyng, nu_Poi, fname, dir_cwd, N_s)
    
    # =========================================================================
    # Solve boundary value problems
    # =========================================================================
    thick_range      = np.linspace(1.*1e-3, 3.5*1e-3, 40)
    beam_twist_range = np.linspace(np.radians(120), np.radians(180), 71)
    stability.PhaseDiagram(beam_twist_range, thick_range[0::4], L_beam=60.*1e-3, Nx_step=65, Ny_step=121)
    