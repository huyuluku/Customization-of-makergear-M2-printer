#### import the simple module from the paraview
from paraview.simple import *
#### disable automatic camera reset on 'Show'
paraview.simple._DisableFirstRenderCameraReset()

# Font --------------------------
font_size = 36
# =============================================================================
# Input parameters
# =============================================================================
# create a new 'Legacy VTK Reader'
fname_ext = '/home/hiromi/Dropbox/Research/Origami/TwistKirigami/AnalysisTools/Static_KirchhoffModel/Energy_KirchhoffModel.vtk'
WarpScale     = 2. #PY_VARIABLE
GridScale_x   = 200. #PY_VARIABLE (For short chain: 100, For long chain: )
ColormapScale = 61.34861756280608
Nx_max = 70
Ny_max = 121
# =============================================================================
# create a new 'Legacy VTK Reader'
# =============================================================================
# Import VTK file
strain_disp_vtk = LegacyVTKReader(FileNames=[fname_ext])
# get active view
renderView1 = GetActiveViewOrCreate('RenderView')
# uncomment following to set a specific view size
# renderView1.ViewSize = [921, 783]

# show data in view
strain_disp_expvtkDisplay = Show(strain_disp_vtk, renderView1)
# trace defaults for the display properties.
strain_disp_expvtkDisplay.Representation = 'Surface'

# reset view to fit data
renderView1.ResetCamera()

# Hide orientation axes
renderView1.OrientationAxesVisibility = 0

#changing interaction mode based on data extents
renderView1.InteractionMode = '3D'

# show color bar/color legend
strain_disp_expvtkDisplay.SetScalarBarVisibility(renderView1, True)

# update the view to ensure updated data information
renderView1.Update()

# get color transfer function/color map for 'point_scalars'
point_scalarsLUT = GetColorTransferFunction('point_scalars')

# Apply a preset using its name. Note this may not work as expected when presets have duplicate names.
point_scalarsLUT.ApplyPreset('jet', True)  # jet or 2hot
# =============================================================================
# create a new 'Delaunay 2D'
# =============================================================================
delaunay2D1 = Delaunay2D(Input=strain_disp_vtk)

# show data in view
delaunay2D1Display = Show(delaunay2D1, renderView1)
# trace defaults for the display properties.
delaunay2D1Display.Representation = 'Surface'

# hide data in view
Hide(strain_disp_vtk, renderView1)

# show color bar/color legend
delaunay2D1Display.SetScalarBarVisibility(renderView1, True)

# update the view to ensure updated data information
renderView1.Update()

# =============================================================================
# create a new 'Warp By Scalar'
# =============================================================================
warpByScalar1 = WarpByScalar(Input=delaunay2D1)

# Properties modified on warpByScalar1
warpByScalar1.ScaleFactor = WarpScale

# show data in view
warpByScalar1Display = Show(warpByScalar1, renderView1)
# trace defaults for the display properties.
warpByScalar1Display.Representation = 'Surface'

# hide data in view
Hide(delaunay2D1, renderView1)

# show color bar/color legend
warpByScalar1Display.SetScalarBarVisibility(renderView1, True)

# update the view to ensure updated data information
renderView1.Update()

# =============================================================================
# create a new 'Loop Subdivision'
# =============================================================================
loopSubdivision1 = LoopSubdivision(Input=warpByScalar1)

# Properties modified on loopSubdivision1
loopSubdivision1.NumberofSubdivisions = 2

# show data in view
loopSubdivision1Display = Show(loopSubdivision1, renderView1)
# trace defaults for the display properties.
loopSubdivision1Display.Representation = 'Surface'

# hide data in view
Hide(warpByScalar1, renderView1)

# show color bar/color legend
loopSubdivision1Display.SetScalarBarVisibility(renderView1, True)

# update the view to ensure updated data information
renderView1.Update()

# =============================================================================
# get color legend/bar for point_scalarsLUT in view renderView1
# =============================================================================
point_scalarsLUTColorBar = GetScalarBar(point_scalarsLUT, renderView1)
# Properties modified on point_scalarsLUTColorBar
point_scalarsLUTColorBar.AutoOrient = 0
point_scalarsLUTColorBar.Orientation = 'Horizontal'

# Properties modified on point_scalarsLUTColorBar
point_scalarsLUTColorBar.Title = 'Energy'
point_scalarsLUTColorBar.TitleFontSize = font_size
point_scalarsLUTColorBar.LabelFontSize = font_size

# Rescale transfer function
#point_scalarsLUT.RescaleTransferFunction(-ColormapScale, ColormapScale)
#point_scalarsLUT.RescaleTransferFunction(-0.6, -0.5)

# get opacity transfer function/opacity map for 'point_scalars'
point_scalarsPWF = GetOpacityTransferFunction('point_scalars')

# change scalar bar placement
point_scalarsLUTColorBar.WindowLocation = 'AnyLocation'
point_scalarsLUTColorBar.Position = [0.08722699983649515, 0.7587948450017415]
point_scalarsLUTColorBar.ScalarBarLength = 0.2

# Properties modified on point_scalarsLUTColorBar
point_scalarsLUTColorBar.RangeLabelFormat = '%-#1.2f'

### Properties modified on point_scalarsLUTColorBar
#point_scalarsLUTColorBar.UseCustomLabels = 1
#point_scalarsLUTColorBar.CustomLabels = [-ColormapScale, 0.0, ColormapScale]
#point_scalarsLUTColorBar.UseCustomLabels = 1
#point_scalarsLUTColorBar.CustomLabels = [-0.57990711,  0.00504915,  0.38917088]

# Properties modified on point_scalarsLUTColorBar
#point_scalarsLUTColorBar.UseCustomLabels = 1
#point_scalarsLUTColorBar.CustomLabels = [-50.0, 0.0, 50.0]
#point_scalarsLUTColorBar.AddRangeLabels = 0

# reset view to fit data
renderView1.ResetCamera()
# =============================================================================
# Properties modified on renderView1.AxesGrid
# =============================================================================
renderView1.AxesGrid.Visibility = 1

# Properties modified on renderView1.AxesGrid
renderView1.AxesGrid.GridColor = [0.0, 0.0, 0.0]
renderView1.AxesGrid.ZLabelOpacity = 0.0

# reset view to fit data bounds
#renderView1.ResetCamera(1.0, 20.0, 0.0, 0.600000023842, -0.578562915325, 1.03565680981)

# Properties modified on loopSubdivision1Display
loopSubdivision1Display.Scale = [1.0, GridScale_x, 1.0]

# Properties modified on renderView1.AxesGrid
renderView1.AxesGrid.AxesToLabel = 27

# Properties modified on renderView1.AxesGrid
renderView1.AxesGrid.XTitle = 'Hub rotation'
renderView1.AxesGrid.YTitle = 'Height'
renderView1.AxesGrid.ZTitle = 'Energy'
renderView1.AxesGrid.XTitleFontSize = font_size
renderView1.AxesGrid.YTitleFontSize = font_size
renderView1.AxesGrid.ZTitleFontSize = font_size
renderView1.AxesGrid.XLabelFontSize = font_size
renderView1.AxesGrid.YLabelFontSize = font_size
renderView1.AxesGrid.ZLabelFontSize = font_size
#renderView1.AxesGrid.XAxisUseCustomLabels = 1
#renderView1.AxesGrid.XAxisLabels = [-Nx_max,0,Nx_max]
#renderView1.AxesGrid.YAxisUseCustomLabels = 1
#renderView1.AxesGrid.YAxisPrecision = 1
#renderView1.AxesGrid.YAxisNotation = 'Fixed'
#renderView1.AxesGrid.YAxisLabels = [0,Nx_max/3.,Nx_max*2./3.,Nx_max]
# Data scale
renderView1.AxesGrid.DataScale = [1.0, GridScale_x, 1.0]

# Properties modified on renderView1.AxesGrid
renderView1.AxesGrid.DataBoundsInflateFactor = 0.0

# update the view to ensure updated data information
renderView1.Update()
# =============================================================================
# current camera placement for renderView1
# =============================================================================
#renderView1.CameraPosition = [70.23346228202273, -25.42869613947793, 41.698828169345774]
#renderView1.CameraFocalPoint = [17.57900179411856, 11.701711629830932, 3.5775021178628545]
#renderView1.CameraViewUp = [-0.4769803504563607, 0.2018477140261918, 0.8554222615883503]
#renderView1.CameraParallelScale = 10.937157944358066

# current camera placement for renderView1
renderView1.CameraPosition = [-498.88435366545133, -155.69616303012657, 501.99473035734763]
renderView1.CameraFocalPoint = [6.006870133689219e-14, 92.30989962816211, 126.95741653442366]
renderView1.CameraViewUp = [0.48085288795837894, 0.28607469289380555, 0.8288195040102528]
renderView1.CameraParallelScale = 118.72323216194148
## reset view to fit data
#renderView1.ResetCamera()
Render()