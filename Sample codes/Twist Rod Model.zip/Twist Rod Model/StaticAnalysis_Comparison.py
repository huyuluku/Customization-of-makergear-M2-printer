import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from scipy.integrate import solve_bvp
from scipy import integrate
from scipy import signal
import scipy.optimize as opt
from scipy import interpolate
import os
import shutil   #High level file operation
import time
import sys
import re
# Import other python codes
sys.path.append('./Static_Experiments') #Directory name
sys.path.append('./Static_KirchhoffModel') #Directory name
from KirigamiStaticExperiment import Kirigami_StaticAnalysis_Experiment
from KirchhoffRodModel_bvp import Static_KirchhoffRod

# Figure parameters =================================================
# When you insert the figure, you need to make fig height 2
plt.rcParams['font.family']     = 'sans-serif'
plt.rcParams['figure.figsize']  = 8, 6      # (w=3,h=2) multiply by 3
plt.rcParams['font.size']       = 24        # Original fornt size is 8, multipy by above number
#plt.rcParams['text.usetex']     = True
#plt.rcParams['ps.useafm'] = True
#plt.rcParams['pdf.use14corefonts'] = True
#plt.rcParams['text.latex.preamble'] = '\usepackage{sfmath}'
plt.rcParams['lines.linewidth'] = 3.   
plt.rcParams['lines.markersize'] = 8. 
plt.rcParams['legend.fontsize'] = 20        # Original fornt size is 8, multipy by above number
plt.rcParams['xtick.labelsize'] = 24        # Original fornt size is 8, multipy by above number
plt.rcParams['ytick.labelsize'] = 24        # Original fornt size is 8, multipy by above number
plt.rcParams['xtick.direction'] = 'in'
plt.rcParams['ytick.direction'] = 'in' 
plt.rcParams['figure.subplot.left']  = 0.2
#plt.rcParams['figure.subplot.right']  = 0.7
plt.rcParams['figure.subplot.bottom']  = 0.2
plt.rcParams['savefig.dpi']  = 300


#==============================================================================
# Model the beam of twist kirigami structure as a Kirchhoff rod
#==============================================================================
class TwistKirigami_Static_Comparision:
    def __init__(self, thick, width, R_hub, Nsec_hub,
                 Eyng, nu_Poi, fname, dir_cwd, N_s):
        self.thick  = thick
        self.width  = width
        self.R_hub  = R_hub
        self.Nsec_hub = Nsec_hub
        self.Eyng   = Eyng
        self.nu_Poi = nu_Poi
        self.N_s    = N_s
        self.G_mod  = Eyng/(2.*(1.+nu_Poi))
        self.aspect = width/thick
        n_fourier = np.arange(1,10,2)
        self.l_shape = 0.333*(1-np.sum(192/5/np.pi**5/self.aspect*np.tanh(n_fourier*np.pi/2*self.aspect)))
        self.GJ      = self.l_shape*self.G_mod*width*thick**3
        # Directory where the calculation results are saved
        self.fname      = fname
        self.dir_cwd    = dir_cwd
        self.dir_save   = 'TwistKirigami_VTK_Animation'
        # Parameters for the BVP solver
        self.max_nodes  = 10000
        # CSV files (Experiments)
        if self.thick==1.*1e-3:
            self.dir_csv     = './Static_Experiments/DataFiles/L60mmT1mm'
            self.dir_csv_DIC = './Static_Experiments/DataFiles/DIC_L60mmT1mm'
            # Twist angle: 0 deg --------------------------------
            List_0 = ['CompressionTest_Kirigami_TwistAngle000-60-1_LV_1.csv',
                      'CompressionTest_Kirigami_TwistAngle000-60-1-S2_LV_1.csv',
                      'CompressionTest_Kirigami_TwistAngle000-60-1-S3_LV_13.csv']
            
            # Twist angle: 90 deg --------------------------------
            List_90 = ['CompressionTest_Kirigami_TwistAngle090-60-1_LV_2.csv',
                       'CompressionTest_Kirigami_TwistAngle090-60-1-S2_LV_2.csv',
                       'CompressionTest_Kirigami_TwistAngle090-60-1-S3_LV_14.csv']
            
            # Twist angle: 180 deg --------------------------------
            List_180 = ['CompressionTest_Kirigami_TwistAngle180-60-1_LV_3.csv',
                        'CompressionTest_Kirigami_TwistAngle180-60-1-S2_LV_3.csv',
                        'CompressionTest_Kirigami_TwistAngle180-60-1-S3_LV_15.csv']
            
            # Twist angle: 225 deg --------------------------------
            List_225 = ['CompressionTest_Kirigami_TwistAngle225-60-1_LV_8.csv',
                        'CompressionTest_Kirigami_TwistAngle225-60-1-S2_LV_4.csv',
                        'CompressionTest_Kirigami_TwistAngle225-60-1-S3_LV_16.csv']
            self.List_csv = {'0deg':List_0,
                             '90deg':List_90,
                             '180deg':List_180,
                             '225deg':List_225}
        elif self.thick==2.5*1e-3:
            self.dir_csv  = './Static_Experiments/DataFiles/L60mmT2pt5mm'
            # Twist angle: 0 deg --------------------------------
            List_0 = ['CompressionTest_Kirigami_TwistAngle000-24-2pt5_LV_18',
                      'CompressionTest_Kirigami_TwistAngle000-24-2pt5-S2_LV_1',
                      'CompressionTest_Kirigami_TwistAngle000-24-2pt5-S3_LV_1.csv']
            
            # Twist angle: 90 deg --------------------------------
            List_90 = ['CompressionTest_Kirigami_TwistAngle090-24-2pt5_LV_19.csv',
                       'CompressionTest_Kirigami_TwistAngle090-24-2pt5-S2_LV_2.csv',
                       'CompressionTest_Kirigami_TwistAngle090-24-2pt5-S3_LV_2.csv']
            
            # Twist angle: 180 deg --------------------------------
            List_180 = ['CompressionTest_Kirigami_TwistAngle180-24-2pt5_LV_20.csv',
                        'CompressionTest_Kirigami_TwistAngle180-24-2pt5-S2_LV_3.csv',
                        'CompressionTest_Kirigami_TwistAngle180-24-2pt5-S3_LV_3.csv']
            
            # Twist angle: 225 deg --------------------------------
            List_225 = ['CompressionTest_Kirigami_TwistAngle225-24-2pt5_LV_24.csv',
                        'CompressionTest_Kirigami_TwistAngle225-24-2pt5-S2_LV_4.csv',
                        'CompressionTest_Kirigami_TwistAngle225-24-2pt5-S3_LV_4.csv']
            self.List_csv = {'0deg':List_0,
                             '90deg':List_90,
                             '180deg':List_180,
                             '225deg':List_225}
        else:
            print('Please select the correct thickness value!')
        
        
    def modelfunc(self, x, p, fexp_ave):
        Eyng = p[0]
        G_mod = Eyng/(2.*(1.+self.nu_Poi))
        GJ    = self.l_shape*G_mod*self.width*self.thick**3
        fexp_norm = fexp_ave/GJ        
        return (fexp_norm)

    def residue(self, p, y, x, err, fexp_ave):
        res = ((y - self.modelfunc(x, p, fexp_ave))/err)
        return (res)
    
    def Estimate_YoungsModulus(self, L_beam):
        beam_twist = 0.
        # =============================================================================
        # Experiment
        # =============================================================================
        disp_sign = -1   # disp_sign: 1 (tension is positive), -1 (compression is positive)
        n_conv    = 40   # Parameter for moving average filter based on convolution (1: No filter)
        n_intp    = 400
        height0   = 50.  # [mm] Initia height used in the experiment
        kiri_exp  = Kirigami_StaticAnalysis_Experiment(self.dir_csv, disp_sign, n_conv)
        kiri_exp.Analyze_std(self.List_csv['{}deg'.format(int(np.degrees(beam_twist)))], height0, n_intp, fig_flag=False)
        fexp_ave   = kiri_exp.fcomp_ave*L_beam*L_beam
        H_exp_norm = (height0 - kiri_exp.displ_comp) / (L_beam*1e3)
        
        
        # Interpolation
        Force1d_exp = interpolate.interp1d(H_exp_norm, fexp_ave)
        N_step  = 100
        h_range = np.linspace(0.64, 0.21, N_step)
        f_intpl = Force1d_exp(h_range)
        # =====================================================================
        # Kirchhoff's rod model
        # =====================================================================
        p0      = [2.2*1e6] # Initial guess
        Rot_hub = np.radians(0.)*np.ones(N_step)
        kiri_rod = Static_KirchhoffRod(self.thick, self.width, L_beam, self.R_hub, self.Nsec_hub,
                                       p0[0], self.nu_Poi, self.fname, self.dir_cwd+'/Static_KirchhoffModel', self.N_s)
        result  = kiri_rod.Analyze_Deformation(beam_twist=np.linspace(0., beam_twist, 20),
                                               h_range=h_range, Rot_hub=Rot_hub, fig_flag=False)
        frod_norm  = -result['N2_top']*self.Nsec_hub
        # =============================================================================
        # Apply curve fitting
        # =============================================================================
        error1 = np.ones(N_step)
        print('=== Start optimization ===')
        param_output1 = opt.leastsq(self.residue, p0, args=(frod_norm, h_range, error1, f_intpl),full_output=True)
        Eyng_fit = param_output1[0][0]
        print('Estimated Youngs modulus = {:.6e} (Pa)'.format(Eyng_fit))
        
        # Recalculate based on the estimated Young's modulus
        N_step  = 100
        h_range = np.linspace(2.3/np.pi, 0.6/np.pi, N_step)
        Rot_hub = np.radians(0.)*np.ones(N_step)
        kiri_rod = Static_KirchhoffRod(self.thick, self.width, L_beam, self.R_hub, self.Nsec_hub,
                                       Eyng_fit, self.nu_Poi, self.fname, self.dir_cwd+'/Static_KirchhoffModel', self.N_s)
        result  = kiri_rod.Analyze_Deformation(beam_twist=np.linspace(0., beam_twist, 20),
                                               h_range=h_range, Rot_hub=Rot_hub, fig_flag=False)
        
        frod_norm  = -result['N2_top']*self.Nsec_hub
        energy_ana =  result['Energy']
        
        i_min = np.argmin(energy_ana)
        urod_norm = (h_range[i_min]-h_range)/h_range[i_min]
        
        # =====================================================================
        # Figures
        # =====================================================================
        self.G_mod = Eyng_fit/(2.*(1.+self.nu_Poi))
        self.GJ    = self.l_shape*self.G_mod*self.width*self.thick**3
        # Normalize
        fexp_ave_norm = kiri_exp.fcomp_ave*L_beam*L_beam/self.GJ
        fexp_err_norm = kiri_exp.fcomp_err*L_beam*L_beam/self.GJ
        c_norm     = height0 - kiri_exp.displ_offset
        dipl_exp_norm = (kiri_exp.displ_comp-kiri_exp.displ_offset)/c_norm
        
        color = 'r'
        
        
        fig = plt.figure('Force_Displacement_std_Normalized', figsize=(12, 7))  # journal figsize=(12, 4)
        ax  = fig.add_subplot(111)
        plt.subplots_adjust(left=0.17,right=0.6)
#        grid(True)
        plt.axhline(y=0, linewidth=2, color='k')
        ax.fill_between( dipl_exp_norm, (fexp_ave_norm-fexp_err_norm),(fexp_ave_norm+fexp_err_norm),color=color,alpha=0.3,label='Experiment')
        p1 = ax.plot(dipl_exp_norm, fexp_ave_norm, color=color, linestyle='dashed', linewidth=2)
        p2 = ax.fill(np.NaN,np.NaN,color,alpha=0.3)
        p3 = ax.plot(urod_norm, frod_norm, 'b', label='Kirchhof Rod Model')
        legend1 = ax.legend([(p2[0],p1[0]), p3[0]], ['Experiment', 'Analytical'],bbox_to_anchor=(1.05, 0.5), loc='lower left', borderaxespad=0)
        plt.gca().add_artist(legend1)
        plt.xlabel('Normalized displacement, $u/H_0$')
        plt.ylabel('Normalized force, $FL^2/(GJ)$')
        plt.xlim(0., dipl_exp_norm[-1])
#            plt.ylim(0,1)
        return()
    
    def CompressionTest_comparison(self, L_beam, beam_twist, pixelsize,
                                   height0=50., # [mm] Initial height used in the experiment
                                   Nx_step=70, Ny_step=121, color='r'):
        # =============================================================================
        # Experiment
        # =============================================================================
        disp_sign = -1   # disp_sign: 1 (tension is positive), -1 (compression is positive)
        n_conv    = 40   # Parameter for moving average filter based on convolution (1: No filter)
        n_intp    = 400
        kiri_exp  = Kirigami_StaticAnalysis_Experiment(self.dir_csv, disp_sign, n_conv)
        kiri_exp.Analyze_std(self.List_csv['{}deg'.format(int(np.degrees(beam_twist)))], height0, n_intp, fig_flag=False)
        fexp_ave_norm = kiri_exp.fcomp_ave*L_beam*L_beam/self.GJ
        fexp_err_norm = kiri_exp.fcomp_err*L_beam*L_beam/self.GJ
        energy_exp    = kiri_exp.energy*L_beam/(0.5*comparison.GJ)
        c_norm        = height0 - kiri_exp.displ_offset
        
        # =============================================================================
        # Kirchhoff rod model
        # =============================================================================
        kiri_rod = Static_KirchhoffRod(self.thick, self.width, L_beam, self.R_hub, self.Nsec_hub,
                                       self.Eyng, self.nu_Poi, self.fname, self.dir_cwd+'/Static_KirchhoffModel', self.N_s)
        # Based on energy analysis, predict deformation along energy valley
        kiri_rod.Analyze_2DEnergyLandscape(beam_twist=np.linspace(0., beam_twist, 180),
                                           h_range= np.linspace(2.5/np.pi, 0.6/np.pi, Nx_step),
                                           Rot_hub_range= np.linspace(-np.radians(80), np.radians(80), Ny_step),
                                           height0=2./np.pi, fig_flag=False, vtk_flag=False)
        
        frod_norm  = -self.Nsec_hub*kiri_rod.fcomp
        urod_norm  = (kiri_rod.height_enemin - kiri_rod.height)/kiri_rod.height_enemin
        energy_rod = self.Nsec_hub*kiri_rod.energy_diff
        # =============================================================================
        # Figures
        # =============================================================================
        fig = plt.figure('Force_Displacement_std_Normalized', figsize=(12, 7))  # journal figsize=(12, 4)
        ax  = fig.add_subplot(111)
        plt.subplots_adjust(left=0.17,right=0.6)
#        grid(True)
        plt.axhline(y=0, linewidth=2, color='k')
        ax.fill_between( (kiri_exp.displ_comp-kiri_exp.displ_offset)/c_norm, (fexp_ave_norm-fexp_err_norm),(fexp_ave_norm+fexp_err_norm),color=color,alpha=0.3,label='Experiment')
        p1 = ax.plot((kiri_exp.displ_comp-kiri_exp.displ_offset)/c_norm, fexp_ave_norm, color=color, linestyle='dashed', linewidth=2)
        p2 = ax.fill(np.NaN,np.NaN,color,alpha=0.3)
        p3 = ax.plot(urod_norm, frod_norm, color=color, label='Kirchhof Rod Model')
        legend1 = ax.legend([(p2[0],p1[0]), p3[0]], ['Experiment', 'Kirchhof model'],bbox_to_anchor=(1.05, 0.5), loc='lower left', borderaxespad=0)
        plt.gca().add_artist(legend1)
        plt.xlabel('Normalized displacement, $u/H_0$')
        plt.ylabel('Normalized force, $FL^2/(GJ)$')
        plt.xlim(left=0.)
#        plt.ylim(0,1)
        
        fig = plt.figure('Energy', figsize=(12, 7))  # journal figsize=(12, 4)
        ax  = fig.add_subplot(111)
        plt.subplots_adjust(left=0.17,right=0.6)
#        grid(True)
        plt.axhline(y=0, linewidth=2, color='k')
#        ax.fill_between( (kiri_exp.displ_comp-kiri_exp.displ_offset)/c_norm, (fexp_ave_norm-fexp_err_norm),(fexp_ave_norm+fexp_err_norm),color=color,alpha=0.3,label='Experiment')
#        p1 = ax.plot((kiri_exp.displ_comp-kiri_exp.displ_offset)/c_norm, fexp_ave_norm, color=color, linestyle='dashed', linewidth=2)
#        p2 = ax.fill(np.NaN,np.NaN,color,alpha=0.3)
        p1 = ax.plot((kiri_exp.displ_comp-kiri_exp.displ_offset)/c_norm, energy_exp, linestyle='dashed', color=color, label='Experiment')
        p2 = ax.plot(urod_norm, energy_rod, linestyle='solid', color=color, label='Kirchhof Rod Model')
        legend1 = ax.legend([p1[0], p2[0]], ['Experiment', 'Kirchhof model'],bbox_to_anchor=(1.05, 0.5), loc='lower left', borderaxespad=0)
        plt.gca().add_artist(legend1)
        plt.xlabel('Normalized displacement, $u/H_0$')
        plt.ylabel('Energy gap, $\Delta U=U(H, \\theta)-U_0$')
        plt.xlim(left=0.)
#        plt.ylim(0,1)
        
        if beam_twist == np.radians(180):
            fig = plt.figure('Hub_Rotation_comparison')
            ax  = fig.add_subplot(111)
            ax.plot(urod_norm, np.degrees(kiri_rod.hub_rot),'b',label='Kirchoff Rod Model')
            linelist = [line.rstrip('\n') for line in open(self.dir_csv_DIC+'/CompressionTest_Kirigami_TwistAngle180-60-1_rot.csv')]
            linelist = linelist[2:]
            strings = [re.findall('-?\ *[0-9]+\.?[0-9]*(?:[Ee]\ *-?\ *[0-9]+)?',s) for s in linelist]
            x = np.array([float(s[1]) for s in strings])
            y = np.array([float(s[2]) for s in strings])
            x = (x-x[0])*pixelsize/1000
            y = (-(y-y[0])*pixelsize-height0+c_norm)/c_norm
            theta = np.rad2deg(np.arcsin(x/0.012))
            ax.plot(y[5:],theta[5:],'m',linestyle='dashed',linewidth=2)
            ax.legend(['Analytical','Experimental'])
            plt.xlabel('Normalized displacement, $u/H_0$')
            plt.ylabel('Hub rotation, $\\theta$ (deg)')
        return()
    
    

            
if __name__ == "__main__":
    # =========================================================================
    # Input information
    # =========================================================================
    # Geometrical parameter
    thick    = 1.*1e-3   # [m]: Thickness of the beam
    width    = 5.*1e-3   # [m]: Height of the beam
    R_hub    = 10.*1e-3  # [m]: Radius of the hub
    Nsec_hub = 6       # Number of sides for the hub
    # Material property
    Eyng     = 2.389905e+06  # [Pa]: Young's modulus of PDMS (Based on optimization)
    nu_Poi   = 0.45      # Poisson's ratio
    N_s      = 200
    # Directory where the calculation results are saved
    fname   ='TwistKirigami_rod'
    dir_cwd = os.getcwd()
    
    comparison = TwistKirigami_Static_Comparision(thick, width, R_hub, Nsec_hub,
                                  Eyng, nu_Poi, fname, dir_cwd, N_s)
    
    # =========================================================================
    # Comparison between experiments and Kirchhoff rod model
    # =========================================================================
    # Estimate the Young's modulus
#    comparison.Estimate_YoungsModulus(L_beam=60.*1e-3)
    
    # Compare experiments with numerics
    comparison.CompressionTest_comparison(L_beam=60.*1e-3, beam_twist=np.radians(0), Nx_step=80, Ny_step=161, pixelsize=1, color='r')
    comparison.CompressionTest_comparison(L_beam=60.*1e-3, beam_twist=np.radians(90), Nx_step=80, Ny_step=161, pixelsize=1, color='b')
    comparison.CompressionTest_comparison(L_beam=60.*1e-3, beam_twist=np.radians(180), Nx_step=80, Ny_step=161, pixelsize=1, color='g')