#### import the simple module from the paraview
from paraview.simple import *
import glob     #Get file list by using wildcard
#### disable automatic camera reset on 'Show'
paraview.simple._DisableFirstRenderCameraReset()

# Font --------------------------
font_size = 36
# =============================================================================
# Input parameters
# =============================================================================
# create a new 'Legacy VTK Reader'
dir_vtk = '/home/hiromi/Dropbox/Research/Origami/TwistKirigami/AnalysisTools/Static_KirchhoffModel/' #PY_VARIABLE
n_beam  = 6 #PY_VARIABLE
data_show = 'k1' #PY_VARIABLE
# =============================================================================
# Import VTK files
# =============================================================================
# Hub (Bottom) -------------------------
hub_Bottomvtk = LegacyVTKReader(FileNames=[dir_vtk+'/Hub_Bottom.vtk'])

# Hub (Top) ----------------------------
dfile  = glob.glob(dir_vtk+"/Hub_Top_*")
N_step = len(dfile)
file_hub = []
for i_file in range(N_step):
    file_hub.append(dir_vtk+"/Hub_Top_{}.vtk".format(int(i_file)))
hub_Top_ = LegacyVTKReader(FileNames=file_hub)

# get animation scene
animationScene1 = GetAnimationScene()

# update animation scene based on data timesteps
animationScene1.UpdateAnimationUsingDataTimeSteps()

# Beams ----------------------------
VTK_beam = []
for i_beam in range(n_beam):
    file_beam = []
    for i_file in range(N_step):
        file_beam.append(dir_vtk+"/TwistKirigami_VTK_Animation_rod{0}_{1}.vtk".format(int(i_beam),
                                                                                     str(i_file).zfill(3)))
    VTK_beam.append(LegacyVTKReader(FileNames=file_beam))

# =============================================================================
# Color bar
# =============================================================================
# get active view
renderView1 = GetActiveViewOrCreate('RenderView')
# uncomment following to set a specific view size
# renderView1.ViewSize = [1198, 772]

# get color transfer function/color map for 'k1'
k1LUT = GetColorTransferFunction(data_show)

# get opacity transfer function/opacity map for 'k1'
k1PWF = GetOpacityTransferFunction(data_show)


# show data in view -----------------------------------------------------
# Hub (bottom)
# show data in view
hub_BottomvtkDisplay = Show(hub_Bottomvtk, renderView1)
# trace defaults for the display properties.
hub_BottomvtkDisplay.Representation = 'Surface'
hub_BottomvtkDisplay.ColorArrayName = [None, '']
hub_BottomvtkDisplay.EdgeColor = [0.0, 0.0, 0.0]
hub_BottomvtkDisplay.OSPRayScaleFunction = 'PiecewiseFunction'
hub_BottomvtkDisplay.SelectOrientationVectors = 'None'
hub_BottomvtkDisplay.ScaleFactor = 0.03849001824855805
hub_BottomvtkDisplay.SelectScaleArray = 'None'
hub_BottomvtkDisplay.GlyphType = 'Arrow'
hub_BottomvtkDisplay.GlyphTableIndexArray = 'None'
hub_BottomvtkDisplay.DataAxesGrid = 'GridAxesRepresentation'
hub_BottomvtkDisplay.PolarAxes = 'PolarAxesRepresentation'
hub_BottomvtkDisplay.ScalarOpacityUnitDistance = 0.2855627664861026

# Hub (Top)
# show data in view
hub_Top_Display = Show(hub_Top_, renderView1)
# trace defaults for the display properties.
hub_Top_Display.Representation = 'Surface'
hub_Top_Display.ColorArrayName = [None, '']
hub_Top_Display.EdgeColor = [0.0, 0.0, 0.0]
hub_Top_Display.OSPRayScaleFunction = 'PiecewiseFunction'
hub_Top_Display.SelectOrientationVectors = 'None'
hub_Top_Display.ScaleFactor = 0.050037020444869997
hub_Top_Display.SelectScaleArray = 'None'
hub_Top_Display.GlyphType = 'Arrow'
hub_Top_Display.GlyphTableIndexArray = 'None'
hub_Top_Display.DataAxesGrid = 'GridAxesRepresentation'
hub_Top_Display.PolarAxes = 'PolarAxesRepresentation'
hub_Top_Display.ScalarOpacityUnitDistance = 0.36840629543599823

# Beams
for i_beam in range(n_beam):
    twistKirigami_VTK_Animation_rod3_0Display = Show(VTK_beam[i_beam], renderView1)
    # trace defaults for the display properties.
    twistKirigami_VTK_Animation_rod3_0Display.Representation = 'Surface'
    twistKirigami_VTK_Animation_rod3_0Display.ColorArrayName = ['CELLS', data_show]
    twistKirigami_VTK_Animation_rod3_0Display.LookupTable = k1LUT
    twistKirigami_VTK_Animation_rod3_0Display.EdgeColor = [0.0, 0.0, 0.0]
    twistKirigami_VTK_Animation_rod3_0Display.OSPRayScaleArray = 'k1'
    twistKirigami_VTK_Animation_rod3_0Display.OSPRayScaleFunction = 'PiecewiseFunction'
    twistKirigami_VTK_Animation_rod3_0Display.SelectOrientationVectors = 'None'
    twistKirigami_VTK_Animation_rod3_0Display.ScaleFactor = 0.09187499769032002
    twistKirigami_VTK_Animation_rod3_0Display.SelectScaleArray = data_show
    twistKirigami_VTK_Animation_rod3_0Display.GlyphType = 'Arrow'
    twistKirigami_VTK_Animation_rod3_0Display.GlyphTableIndexArray = data_show
    twistKirigami_VTK_Animation_rod3_0Display.DataAxesGrid = 'GridAxesRepresentation'
    twistKirigami_VTK_Animation_rod3_0Display.PolarAxes = 'PolarAxesRepresentation'
    twistKirigami_VTK_Animation_rod3_0Display.ScalarOpacityFunction = k1PWF
    twistKirigami_VTK_Animation_rod3_0Display.ScalarOpacityUnitDistance = 0.16146131594752652
    
    # init the 'GridAxesRepresentation' selected for 'DataAxesGrid'
    twistKirigami_VTK_Animation_rod3_0Display.DataAxesGrid.XTitleColor = [0.0, 0.0, 0.0]
    twistKirigami_VTK_Animation_rod3_0Display.DataAxesGrid.YTitleColor = [0.0, 0.0, 0.0]
    twistKirigami_VTK_Animation_rod3_0Display.DataAxesGrid.ZTitleColor = [0.0, 0.0, 0.0]
    twistKirigami_VTK_Animation_rod3_0Display.DataAxesGrid.XLabelColor = [0.0, 0.0, 0.0]
    twistKirigami_VTK_Animation_rod3_0Display.DataAxesGrid.YLabelColor = [0.0, 0.0, 0.0]
    twistKirigami_VTK_Animation_rod3_0Display.DataAxesGrid.ZLabelColor = [0.0, 0.0, 0.0]
    
    # init the 'PolarAxesRepresentation' selected for 'PolarAxes'
    twistKirigami_VTK_Animation_rod3_0Display.PolarAxes.PolarAxisTitleColor = [0.0, 0.0, 0.0]
    twistKirigami_VTK_Animation_rod3_0Display.PolarAxes.PolarAxisLabelColor = [0.0, 0.0, 0.0]
    twistKirigami_VTK_Animation_rod3_0Display.PolarAxes.LastRadialAxisTextColor = [0.0, 0.0, 0.0]
    twistKirigami_VTK_Animation_rod3_0Display.PolarAxes.SecondaryRadialAxesTextColor = [0.0, 0.0, 0.0]
    
    # reset view to fit data
    renderView1.ResetCamera()
    
    # show color bar/color legend
    twistKirigami_VTK_Animation_rod3_0Display.SetScalarBarVisibility(renderView1, True)

# update the view to ensure updated data information
renderView1.Update()
# set active source
SetActiveSource(VTK_beam[0])

# Apply a preset using its name. Note this may not work as expected when presets have duplicate names.
k1LUT.ApplyPreset('Blue to Red Rainbow', True)

# =============================================================================
# current camera placement for renderView1
# =============================================================================
#renderView1.CameraPosition = [70.23346228202273, -25.42869613947793, 41.698828169345774]
#renderView1.CameraFocalPoint = [17.57900179411856, 11.701711629830932, 3.5775021178628545]
#renderView1.CameraViewUp = [-0.4769803504563607, 0.2018477140261918, 0.8554222615883503]
#renderView1.CameraParallelScale = 10.937157944358066

# current camera placement for renderView1
renderView1.CameraPosition = [1.3650122493786248, 1.0807480563343204, 1.870054193246551]
renderView1.CameraFocalPoint = [0.5356737332552091, 0.01272153831119649, 0.08687193414746736]
renderView1.CameraViewUp = [0.9274100482295731, -0.14325467411686146, -0.3455267005406284]
renderView1.CameraParallelScale = 0.478688115734753
## reset view to fit data
#renderView1.ResetCamera()
Render()