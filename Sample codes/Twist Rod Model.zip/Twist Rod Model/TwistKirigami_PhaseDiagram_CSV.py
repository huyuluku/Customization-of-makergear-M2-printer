import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from scipy.integrate import solve_bvp
from scipy import integrate
from scipy import signal
import os
import shutil   #High level file operation
import time
import sys
from KirchhoffRodModel_bvp import Static_KirchhoffRod

# Figure parameters =================================================
# When you insert the figure, you need to make fig height 2
plt.rcParams['font.family']     = 'sans-serif'
plt.rcParams['figure.figsize']  = 8, 6      # (w=3,h=2) multiply by 3
plt.rcParams['font.size']       = 24        # Original fornt size is 8, multipy by above number
#plt.rcParams['text.usetex']     = True
#plt.rcParams['ps.useafm'] = True
#plt.rcParams['pdf.use14corefonts'] = True
#plt.rcParams['text.latex.preamble'] = '\usepackage{sfmath}'
plt.rcParams['lines.linewidth'] = 3.   
plt.rcParams['lines.markersize'] = 8. 
plt.rcParams['legend.fontsize'] = 20        # Original fornt size is 8, multipy by above number
plt.rcParams['xtick.labelsize'] = 24        # Original fornt size is 8, multipy by above number
plt.rcParams['ytick.labelsize'] = 24        # Original fornt size is 8, multipy by above number
plt.rcParams['xtick.direction'] = 'in'
plt.rcParams['ytick.direction'] = 'in' 
plt.rcParams['figure.subplot.left']  = 0.2
#plt.rcParams['figure.subplot.right']  = 0.7
plt.rcParams['figure.subplot.bottom']  = 0.2
plt.rcParams['savefig.dpi']  = 300


#==============================================================================
# Model the beam of twist kirigami structure as a Kirchhoff rod
#==============================================================================
class TwistKirigami_StabilityAnalysis:
    def __init__(self, thick, width, R_hub, Nsec_hub,
                 Eyng, nu_Poi, fname, dir_cwd, N_s):
        self.thick  = thick
        self.width  = width
        self.R_hub  = R_hub
        self.Nsec_hub = Nsec_hub
        self.Eyng   = Eyng
        self.nu_Poi = nu_Poi
        self.N_s    = N_s
        # Directory where the calculation results are saved
        self.fname      = fname
        self.dir_cwd    = dir_cwd
        self.dir_save   = 'TwistKirigami_VTK_Animation'
        # Parameters for the BVP solver
        self.max_nodes  = 10000

    
    
    def PhaseDiagram_csv(self, file_csv):
        data = np.genfromtxt(file_csv, skip_header = 1, delimiter=',')
        N_twist = len(np.where(data[:,0] == data[0,0])[0])
        beam_twist_range = data[0:N_twist,1]
        thickness_range  = data[::N_twist,0]
        N_thick          = len(thickness_range)
        num_LocalMinima  = np.zeros((N_thick,N_twist))
        for i_beam in range(N_thick):
            i0 = N_twist*i_beam
            i1 = N_twist*(i_beam+1)
            num_LocalMinima[i_beam,:] = data[i0:i1,2]
        
        plt.figure('Number of local minimum points')
        plt.plot(np.degrees(beam_twist_range), num_LocalMinima[0,:], 'bo')
        plt.plot(np.degrees(beam_twist_range), num_LocalMinima[1,:], 'ro')
        plt.xlabel('Beam twist angle, $\phi$ (deg)')
        plt.ylabel('# of minima')
                   
        dx = beam_twist_range[1] - beam_twist_range[0]
        dy = thickness_range[1] - thickness_range[0]
        plt.figure('Phase diagram', figsize=(14, 8))  # For journal figsize=(12, 8)
        plt.imshow(num_LocalMinima, aspect = 'auto',cmap=plt.cm.Paired, origin='lower',interpolation='nearest',
#                   vmin=1.25,
                   vmax=4,
                   extent=[np.degrees(beam_twist_range[0]-0.5*dx), np.degrees(beam_twist_range[-1]+0.5*dx),
                           (thickness_range[0]-0.5*dy)/self.width, (thickness_range[-1]+0.5*dy)/self.width]
                   )
        # Prototype configuration
        markersize = 12
        plt.axhline(y=2.25/5, linewidth=3, linestyle='--', color='k')
        plt.plot(120, 2.25/5,'ko',markersize=markersize)
        plt.plot(135, 2.25/5,'ko',markersize=markersize)
        plt.plot(150, 2.25/5,'ko',markersize=markersize)
        plt.plot(180, 2.25/5,'ko',markersize=markersize)
        # Label
        plt.xlabel("Beam twist angle, $\phi$ (deg)")
        plt.ylabel("Thickness to width ratio, $h/w$")
        return()
    
    def PhaseDiagram_csv_3files(self, list_csv):
        N_file = len(list_csv)
        data = np.genfromtxt(list_csv[0], skip_header = 1, delimiter=',')
        N_twist = len(np.where(data[:,0] == data[0,0])[0])
        beam_twist_range = data[0:N_twist,1]
        
        n_t = np.zeros(N_file)
        for i in range(N_file):
            data = np.genfromtxt(list_csv[i], skip_header = 1, delimiter=',')
            temp = data[::N_twist,0]
            print(len(temp))
            n_t[i] = len(temp)
        N_thick          = int(sum(n_t))
        num_LocalMinima  = np.zeros((N_thick,N_twist))
        thickness_range  = np.zeros(N_thick)
        for i in range(N_file):
            data = np.genfromtxt(list_csv[i], skip_header = 1, delimiter=',')
            thickness_range[i::N_file]  = data[::N_twist,0]
            for i_beam in range(len(data[::N_twist,0])):
                i0 = N_twist*i_beam
                i1 = N_twist*(i_beam+1)
                num_LocalMinima[N_file*i_beam+i,:] = data[i0:i1,2]
        
        plt.figure('Number of local minimum points')
        plt.plot(np.degrees(beam_twist_range), num_LocalMinima[0,:], 'bo')
        plt.plot(np.degrees(beam_twist_range), num_LocalMinima[1,:], 'ro')
        plt.xlabel('Beam twist angle, $\phi$ (deg)')
        plt.ylabel('# of minima')
                   
        dx = beam_twist_range[1] - beam_twist_range[0]
        dy = thickness_range[1] - thickness_range[0]
        plt.figure('Phase diagram', figsize=(14, 8))  # For journal figsize=(12, 8)
        plt.imshow(num_LocalMinima, aspect = 'auto',cmap=plt.cm.Paired, origin='lower',interpolation='nearest',
#                   vmin=1.25,
                   vmax=4,
                   extent=[np.degrees(beam_twist_range[0]-0.5*dx), np.degrees(beam_twist_range[-1]+0.5*dx),
                           (thickness_range[0]-0.5*dy)/self.width, (thickness_range[-1]+0.5*dy)/self.width]
                   )
        # Prototype configuration
        markersize = 12
        plt.axhline(y=2.25/5, linewidth=3, linestyle='--', color='k')
        plt.plot(120, 2.25/5,'ko',markersize=markersize)
        plt.plot(135, 2.25/5,'ko',markersize=markersize)
        plt.plot(150, 2.25/5,'ko',markersize=markersize)
        plt.plot(180, 2.25/5,'ko',markersize=markersize)
        # Label
        plt.xlabel("Beam twist angle, $\phi$ (deg)")
        plt.ylabel("Thickness to width ratio, $h/w$")
        return()
    
   
    
if __name__ == "__main__":
    # =========================================================================
    # Input information
    # =========================================================================
    # Geometrical parameter
    thick  = 1.*1e-3   # [m]: Thickness of the beam
    width  = 5.*1e-3   # [m]: Height of the beam
    R_hub  = 10.*1e-3  # [m]: Radius of the hub
    Nsec_hub = 6       # Number of sides for the hub
    # Material property
    Eyng   = 2.389905e+06  # [Pa]: Young's modulus of PDMS (Based on optimization)
    nu_Poi = 0.45      # Poisson's ratio
    N_s    = 200
    # Directory where the calculation results are saved
    fname   ='TwistKirigami_rod'
    dir_cwd = os.getcwd()
    
    stability = TwistKirigami_StabilityAnalysis(thick, width, R_hub, Nsec_hub,
                                  Eyng, nu_Poi, fname, dir_cwd, N_s)
    
    # =========================================================================
    # Solve boundary value problems
    # =========================================================================
#    beam_twist_range = np.array([0., np.radians(147)])
#    beam_twist_range = np.linspace(0, np.pi, 40)
#    stability.PhaseDiagram(beam_twist_range=beam_twist_range, L_beam=60.*1e-3)
    
#    L_beam_range     = np.linspace(60.*1e-3, 90.*1e-3, 16)
#    beam_twist_range = np.linspace(np.radians(90), np.radians(135), 46)
#    stability.PhaseDiagram2(beam_twist_range, L_beam_range)
    
    thick_range      = np.linspace(1.*1e-3, 3.5*1e-3, 26)
    beam_twist_range = np.linspace(np.radians(120), np.radians(180), 61)
#    thick_range      = np.linspace(3.5*1e-3, 5.*1e-3, 16)
#    beam_twist_range = np.linspace(np.radians(120), np.radians(180), 61)
#    stability.PhaseDiagram3(beam_twist_range, thick_range[14::3], L_beam=60.*1e-3, Nx_step=65, Ny_step=121)
    # Import csv
#    stability.PhaseDiagram_csv(file_csv='StabilityAnalysisResults_result1.csv')
    stability.PhaseDiagram_csv_3files(list_csv=['StabilityAnalysisResults_result0.csv',
                                                'StabilityAnalysisResults_result1.csv',
                                                'StabilityAnalysisResults_result2.csv',
                                                'StabilityAnalysisResults_result3.csv'])